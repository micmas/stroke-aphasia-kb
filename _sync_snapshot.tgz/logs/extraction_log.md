# Extraction log

A running, append-only audit log of every agent extraction run and every
human review action. Every entry is one line, pipe-separated, in this
format:

```
<ISO date> | <ACTION> | <citation> | <entry id> | <metadata...>
```

Actions:

- `EXTRACTED` — agent wrote one or more drafts from a paper.
- `APPROVED`  — human moved a draft to the canonical folder.
- `REJECTED`  — human marked a draft as rejected (it stays in `drafts/`
                with `status: rejected` for the audit trail).
- `EDITED`    — human manually edited a canonical entry without going
                through `promote.py` (please add this manually if so).

This log is appended to automatically by `promote.py`. The agent should
add an `EXTRACTED` line for every run.

---

<!-- New entries are appended below this line -->
2026-04-30 | EXTRACTED | @Yourganov2015Predicting | brocas_aphasia, wernickes_aphasia, conduction_aphasia, global_aphasia, anomic_aphasia | 5 drafts (impairment-anchored) | 9 findings | confidence: high (4) / medium (1, Wernicke's small n) | annotator: 20/36 quotes placed (16 missed due to Unicode/line-break artifacts in PDF text extraction) | agent: claude-opus-4-7
2026-05-01 | EXTRACTED | @Alyahya2018NounVerb | phonological_production, semantics, fluency, phonological_recognition, executive_functions, lesion_volume | 6 drafts (5 impairment-anchored PCA-factor drafts + 1 predictor-anchored lesion_volume draft) | 24 findings | confidence: high (all) | flags: many target_ids do not yet exist as canonical region entries (anterior/posterior arcuate, angular gyrus, parietal operculum, posterior supramarginal gyrus, ILF, anterior MTG, temporal pole, superior lateral occipital cortex, precuneus, central opercular cortex, pre-central gyrus, Heschl's gyrus, planum temporale, posterior STG, superior frontal gyrus, paracingulate gyrus, supplementary motor area); method 'VBCM' coded as VLSM throughout (controlled-vocab limitation); fluency findings flagged as lesion-volume-confounded; semantics findings flagged for partial cluster shrinkage under lesion-volume covariate | agent: claude-opus-4-7
2026-05-01 | EXTRACTED | @Barbieri2023 | treatment_of_underlying_forms, typicality_semantic_feature_analysis, spell_study_spell | 3 drafts (therapy-anchored) | 7 findings | confidence: high (all) | flags: target_ids for impairments (agrammatism, anomia, dysgraphia, sentence_comprehension, sentence_production) and right-hemisphere regions (right_anterior_middle_temporal_gyrus, right_anterior_superior_temporal_gyrus) do not yet exist as canonical entries; behavioural-efficacy findings coded as method=clinical_RCT; fMRI-activation findings include enantiomorphic-replacement preprocessing; spell-study-spell f2 has unexpected RH upregulation without behavioral coupling, interpreted post-hoc as phonological-discrimination side effect; sentence-treatment f3 (brain-behavior coupling) is the headline finding linking RH activation change to verb comprehension improvement | agent: claude-opus-4-7
2026-05-01 | RE-EXTRACTED | @Yourganov2015Predicting | brocas_aphasia, conduction_aphasia, wernickes_aphasia, global_aphasia, anomic_aphasia | 5 drafts (impairment-anchored, refresh of 2026-04-30 extraction under v2.4 conventions) | 25 findings (Broca's 7, conduction 3, Wernicke's 7, global 8, anomic 0 null) | confidence: high (Broca's, conduction, global) / medium (Wernicke's, n=7) | conventions applied: hemisphere-prefixed target IDs (left_*); cross-paper cohort-overlap flag pointing to @Fridriksson2018 on every finding (shared USC registry); legacy ho-cort_44 retained for the IFG pars opercularis target since the canonical entry already exists; no per-finding flags about non-existent target IDs (forward-looking convention); anomic_aphasia uses the empty-findings null pattern (paper specifically reports no regions reach Z>1) | annotator: 131/139 quotes placed; 8 missed (line-break artifacts in PDF text) | agent: claude-opus-4-7
2026-05-01 | EXTRACTED | @Fridriksson2018 | form_to_articulation, form_to_meaning | 2 drafts (impairment-anchored; first proper extraction — the canonical regions/ho-cort_44.md previously cited this paper with [PLACEHOLDER] source passages from the worked example) | 12 findings (form_to_articulation 5: pars opercularis, premotor, MFG, anterior SMG, precentral; form_to_meaning 7: posterior MTG, posterior STG, uncinate, posterior SMG, angular, pars orbitalis, anterior MTG) | confidence: high (all) | method: VLSM (the paper's actual analysis is VLSM-then-PCA: 71 univariate VLSMs are stacked into a PCA, where Component 2's positive vs negative loadings define the dual-stream split) | sample n=138 chronic LH stroke patients from USC Aphasia Lab archival database, ≥6 months post-stroke; cohort substantially overlaps with @Yourganov2015Predicting (cohort-overlap flag on every finding) | conventions applied: hemisphere-prefixed target IDs (left_*); legacy ho-cort_44 retained; no per-finding non-existent-target flags; cohort-overlap flag pattern; flag on form_to_articulation:f1 noting that the canonical ho-cort_44.md placeholder source passages should be replaced when promote.py runs | DOI corrected in citations.md (was 10.1073/pnas.1714922115; actual is 10.1073/pnas.1614038114 per the PDF) | agent: claude-opus-4-7
2026-05-05 | AUTO-APPROVED | @Yourganov2015Predicting | brocas_aphasia, global_aphasia | 2 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Fridriksson2018 | form_to_articulation, form_to_meaning | 2 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Alyahya2018NounVerb | phonological_production, phonological_recognition | 2 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Alyahya2018NounVerb | lesion_volume (predictor) | 1 draft | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-05 | AUTO-APPROVED | @Barbieri2023 | spell_study_spell, treatment_of_underlying_forms, typicality_semantic_feature_analysis | 3 drafts | PDF-quote-match passed (100%) | all hard+soft checks passed | reviewer: auto-reviewer (require-pdf-match)
2026-05-06 | AUTO-APPROVED | ? | anomic_aphasia | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | conduction_aphasia | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | executive_functions | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | fluency | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | semantics | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | wernickes_aphasia | reviewer: michele
2026-05-06 | EXTRACTED | @Saur2008 | left_arcuate_fasciculus_slf, left_extreme_capsule, left_middle_temporal_gyrus, left_superior_temporal_gyrus | 4 drafts (region-anchored) | 6 findings (2 correlational DTI tract-connectivity + 4 fMRI_activation recruitment) | confidence: high (all) | NOTE: healthy volunteers only (n=33, German-speaking), NO aphasia patients — all findings are correlational or recruitment; causal/aphasia inferences are speculative (Discussion only); DTI acquisition parameters in SI Methods not available in main PDF; method: [DTI, fMRI_activation] multimodal; forward-looking target IDs: speech_repetition, auditory_comprehension; key tracts: left AF/SLF (dorsal, STG→premotor) and left extreme capsule (ventral, MTG→vlPFC BA45/47) | agent: claude-sonnet-4-6

2026-05-06 | EXTRACTED | @Fridriksson2018BDNF | tdcs_aphasia_treatment (therapy), bdnf_val66met (predictor) | 2 drafts | 1 finding (therapy: tDCS × BDNF genotype responder RCT) + 1 finding (predictor: BDNF val/val → greater tDCS response) | confidence: high | flags: cohort overlaps with parent RCT (Fridriksson JAMA Neurol 2018); baseline severity difference between BDNF groups becomes non-significant after lesion/time adjustment | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Dresang2022 | bdnf_val66met (predictor) | 1 draft | 3 findings (BDNF main effect on WAB-AQ; BDNF × cortical excitability interaction; BDNF × stimulation-induced neuroplasticity interaction) | confidence: medium | flags: small sample n=17; LASSO-adjusted R² increase minimal for BDNF alone (footnote 1); direction: mixed for cortical-excitability finding (sign reverses by genotype group) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Robson2019 | left_superior_temporal_gyrus_wernickes (region), auditory_temporal_processing (predictor) | 2 drafts | 4 findings (region: WA lesion overlap in left mid-posterior STG/STS; longitudinal comprehension recovery; predictor: 40-Hz FM at 2.5 MPO → 9 MPO comprehension r=−0.94; word phonological discrimination at 5 MPO → 9 MPO comprehension r=0.84) | confidence: medium | flags: no formal voxel-wise LSM (lesion overlap map only); very small df for cross-lagged correlations (df=6 and df=8); paper published in Neurorehabil Neural Repair NOT Brain (citation corrected from prompt) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Baldo2006 | left_ifg_pars_opercularis (letter_fluency, category_fluency) | 1 draft (region-anchored) | 2 findings (f1: letter fluency -> frontal BA44/BA6/BA4; f2: category fluency -> temporal BA22/37/41/42) | confidence: high | flags: uncorrected p<0.05 threshold (no permutation correction); Talairach 2D template lesion tracing; mixed MRI/CT; no MNI coordinates reported | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Bonilha2014 | left_ifg_pars_triangularis (naming, fluency, auditory_comprehension via BA45/BA22 disconnection) | 1 draft (region-anchored) | 3 findings (f1: BA45 disconnection->naming beta=1.21 p<0.001; f2: BA45 disconnection->fluency beta=7.52 p=0.025; f3: BA22 disconnection->comprehension p=0.01) | confidence: high (f1,f2) / medium (f3: beta value suspect OCR artifact) | flags: cohort overlaps @Fridriksson2018Anatomy (same USC/MUSC lab); DTI params in Online Supplement only; disconnection beta for BA22 (f3) printed as '47' in author manuscript (likely 0.47); reference_space not stated in main text | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Fridriksson2018Anatomy | left_ifg_pars_opercularis (speech_fluency, aphasia_quotient), left_posterior_stg (sentence_comprehension, auditory_word_recognition, naming) | 2 drafts (region-anchored) | 5 findings (IFG opercularis f1: speech fluency R2=0.40 multivariate RLSM; f2: AQ CLSM hub; posterior STG f1: sentence comprehension R2=0.60; f2: auditory word recognition R2=0.31; f3: naming network RLSM+CLSM) | confidence: high (all) | flags: cohort overlaps @Fridriksson2018 (same USC Aphasia Lab archival database; n=138 vs n=159); n varies per test (sentence comprehension n=57, PNT n=105, full n=159); method coded as LSM (RLSM arm) — CLSM arm coded as disconnectome in imaging_details notes; PCA-derived component maps not separately extracted (would require additional drafts for speech production/comprehension components) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @MassonTrottier2021 | phonological_component_analysis (therapy) | 1 draft (therapy-anchored) | 2 findings (f1: increased LH visual-semantic rsFC ant. temporal fusiform bilateral SCC and SCC ant. ITG, relationship: treatment_response; f2: decreased RH rsFC lingual gyrus SFG, relationship: treatment_response) | confidence: high | annotation: 9/9 (100%) | agent: claude-sonnet-4-6
2026-05-06 | REFUSED | @Radanovic2017 | 1-s2.0-S0093934X16301717-main.pdf | reason: Comprehensive narrative review of aphasia in basal ganglia vascular lesions — no primary dataset; secondary synthesis of published case reports and studies.
2026-05-06 | REFUSED | @NadeauCrosson1997 | 1-s2.0-S0093934X97917077-main.pdf | reason: 48-page critical review of subcortical aphasia literature — no primary patient cohort; purely secondary synthesis.
2026-05-06 | REFUSED | @Crosson1999 | 1-s2.0-S0278262699910886-main.pdf | reason: Review of four previously-published thalamic lesion cases — secondary re-analysis of own published data; no new primary dataset.
2026-05-06 | REFUSED | @Wallentin2018 | file.pdf | reason: Meta-analysis and database query on sex differences in post-stroke aphasia rates — no primary patient cohort; aggregate statistical synthesis only.
2026-05-06 | FLAGGED | UNKNOWN | 1-s2.0-S0093934X84710637-main.pdf | reason: Scanned PDF — no extractable text; OCR required before extraction can proceed. Paper appears to be a 1984 Brain and Language article (15 pages). User action needed.
2026-05-06 | FLAGGED | @Pflugshaupt2009 | awp141.pdf | reason: Pure alexia paper (visual field defects in pure alexia) — may be outside KB scope (aphasia vs. reading disorders). User decision needed on whether to include.
2026-05-06 | EXTRACTED | @Harvey2022 | lesion_volume (predictor) | 1 draft (predictor-anchored; 2 findings) | f1: smaller lesion volume → greater long-term WAB-R AQ gain [R2=0.52 F(4,13)=3.51 p=.037]; f2: ALA participation satisfaction → better long-term outcome [combined model R2=0.68 p=.003] | confidence: high (f1) medium (f2) | annotation: 8/8 (100%) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Breining2022 | left_angular_gyrus (region) | 1 draft (region-anchored) | 2 findings (f1: left AG → object naming LASSO=-0.524 p<.001; f2: left AG → action naming LASSO=-0.405 p=.728 in model not independent) | PPA EXCLUDED (non-stroke etiology documented in provenance.flags) | confidence: high | annotation: 8/8 (100%) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Kristinsson2025 | severity_metric (predictor; WAB-R subtest scores) | 1 draft (predictor-anchored) | 2 findings (f1: shared left perisylvian network R2=0.22–0.25 across WAB-R subtests, best DTI r=0.45 auditory comprehension; f2: right putamen uniquely predicts naming/repetition p=0.013/0.021, left STL+right precuneus predict comprehension p=0.049/0.045) | confidence: high (f1) medium (f2: post-hoc exploratory) | annotation: 14/14 (100%) | flags: POLAR trial (NCT03416738) USC/MUSC cohort overlaps @Fridriksson2018, @Yourganov2015Predicting | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Teghipco2024 | severity_metric (predictor; imaging_metric; WAB-AQ binary severe vs non-severe) | 1 draft (predictor-anchored) | 2 findings (f1: 3D CNN balanced accuracy=0.77 F1=0.70 outperforms SVM t(19)=-10 p=5.26e-9 Cohen's d=2.24; f2: right hemisphere morphometry significantly more salient for severe predictions vs left hemisphere for non-severe p<0.0001 all ROIs) | confidence: high | annotation: 14/14 (100%) | flags: cohort overlaps @Fridriksson2018, @Yourganov2015Predicting, @Kristinsson2025 (same USC/MUSC Aphasia Lab, n=231) | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @White2024 | severity_metric (predictor; clinical; CAT spoken picture description aphasic vs non-aphasic) | 1 draft (predictor-anchored) | 2 findings (f1: tabular logistic regression balanced accuracy=0.813; f2: ResNet-18 Hybrid ROI CNN balanced accuracy ~0.85, FDR-corrected significant improvement over baseline) | confidence: high | annotation: 11/11 (100%) | flags: PLORAS cohort (UCL, n=758) distinct from USC/MUSC and BU cohorts — no overlap | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Hu2025 | severity_metric (predictor; behavioural; WAB-R AQ continuous) | 1 draft (predictor-anchored) | 2 findings (f1: multimodal SVR DM+PSW+rsFMRI-FC r=0.73 RMSE=15.82 outperforms single-modality; f2: rsFMRI-FC SHAP=3.65 highest predictor class; left arcuate posterior + fronto-insular tract selected 11/11 folds) | confidence: high | annotation: 13/13 (100%) | flags: Boston University CBR (Kiran lab, n=76) distinct from USC/MUSC and PLORAS cohorts; pipeline mismatch Cohort 1 vs 2 for lesion segmentation and DTI | agent: claude-sonnet-4-6
2026-05-06 | REFUSED | @Mohr2017 | Mohr-2017-Neuroplasticity and Functional Recov.pdf | reason: Opinion/perspective article — no primary patient data, no original lesion-symptom or neuroimaging dataset; only narrative argument and secondary citations.
2026-05-06 | REFUSED | @Raymer | Raymer-Effectiveness of Constraint-Induced Lan.pdf | reason: Systematic review / meta-analysis of CILT studies — no primary dataset; summary statistics only across heterogeneous studies, not extractable as individual findings.
2026-05-06 | REFUSED | @Shekari2022 | Shekari-2022-Mechanisms of brain activation fo.pdf | reason: Narrative systematic review of fMRI activation studies in aphasia therapy — no primary patient cohort; secondary synthesis only.
2026-05-06 | REFUSED | @Simic2023 | Simic-2023-Treatment-induced neuroplasticity a.pdf | reason: Systematic review of treatment-induced neuroplasticity in aphasia — no original dataset; purely a synthesis of published studies.
2026-05-06 | REFUSED | @Watila2015 | Watila-2015-Factors predicting post-stroke aph.pdf | reason: Narrative review of prognostic factors for post-stroke aphasia — no primary data; secondary synthesis.
2026-05-06 | REFUSED | @MirmanThye2018 | mirman-thye-2018-uncovering-the-neuroanatomy-of-core-language-systems-using-lesion-symptom-mapping.pdf | reason: Current Directions in Psychological Science review article — reinterprets previously published LSM data; no new primary dataset extractable.
2026-05-06 | EXTRACTED | @Stefaniak2022 | bilateral_middle_frontal_gyrus_recovery (region; 4 findings) | f1: bilateral MFG + right temporo-occipital MTG activation increase → fluency recovery (beta=0.29-0.30 pre-control, beta=0.38 post-control); f2: bilateral ATL activation decrease → semantic/executive recovery (only with baseline control; false-negative otherwise); f3: bilateral precentral/vmPFC/precuneus decrease → phonology recovery (moderated by baseline severity); f4: right SMG/insula/MTG at T1 cross-sectionally associated with fluency (beta=0.54 P=7.1e-5) | longitudinal fMRI, n=26 left-hemisphere stroke, 2wks→4mths | annotation: 14/15 (93%); 1 missed (method quote p.3 — SPM paragraph variant) | confidence: high (f1,f2,f4) medium (f3: PC3 did not significantly improve) | flags: dataset previously reported in Geranmayeh 2016/2017; key methodological contribution: proportional-recovery confound control via T1 PC score revealed false-negatives (bilateral ATL for semantic/executive) and validated true positives | agent: claude-sonnet-4-6
2026-05-06 | REFUSED | @Brady2022RELEASE | 3040338.pdf | reason: Systematic review and individual participant data network meta-analysis (PROSPERO CRD42018110947) — no primary patient dataset collected by authors; synthesis of 174 datasets from 28 countries (n=5928 IPD); method is meta-analytic not primary.
2026-05-06 | REFUSED | @Wilson2021 | Wilson-2021-Neuroplasticity in post-stroke ap1.pdf | reason: Systematic review and meta-analysis (PROSPERO CRD42018116295) of 86 fMRI/PET studies of neuroplasticity in post-stroke aphasia — no primary patient data; secondary synthesis with methodological appraisal only.
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | brocas_aphasia | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018 | form_to_articulation | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018 | form_to_meaning | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Yourganov2015Predicting | global_aphasia | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | phonological_production | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | phonological_recognition | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018BDNF | bdnf_val66met | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Alyahya2018NounVerb | lesion_volume | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Hu2025 | severity_metric | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Teghipco2024 | severity_metric | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @White2024 | severity_metric | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_anterior_temporal_lobe | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018Anatomy | left_ifg_pars_opercularis | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_middle_temporal_gyrus | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_superior_temporal_gyrus | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Barbieri2023 | spell_study_spell | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Fridriksson2018BDNF | tdcs_aphasia_treatment | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Barbieri2023 | treatment_of_underlying_forms | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Barbieri2023 | typicality_semantic_feature_analysis | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Robson2019 | auditory_temporal_processing | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Dresang2022 | bdnf_val66met | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Marchina2011 | left_arcuate_fasciculus | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_arcuate_fasciculus_slf | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_extreme_capsule | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_frontal_white_matter_bottleneck | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Fridriksson2018Anatomy | left_posterior_stg | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_superior_temporal_gyrus_wernicke | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_supramarginal_gyrus_premotor | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @MassonTrottier2021 | phonological_component_analysis | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Robson2019 | auditory_temporal_processing | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Dresang2022 | bdnf_val66met | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Harvey2022 | lesion_volume | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Kristinsson2025 | severity_metric | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Stefaniak2022 | bilateral_middle_frontal_gyrus_recovery | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Breining2022 | left_angular_gyrus | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Marchina2011 | left_arcuate_fasciculus | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_arcuate_fasciculus_slf | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Saur2008 | left_extreme_capsule | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_frontal_white_matter_bottleneck | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Baldo2006 | left_ifg_pars_opercularis | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Bonilha2014 | left_ifg_pars_triangularis | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Bonilha2014 | left_posterior_stg | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Fridriksson2018Anatomy | left_posterior_stg | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_superior_temporal_gyrus_wernicke | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Robson2019 | left_superior_temporal_gyrus_wernickes | reviewer: michele
2026-05-06 | AUTO-APPROVED | @Mirman2015 | left_supramarginal_gyrus_premotor | reviewer: michele
2026-05-06 | AUTO-APPROVED | @MassonTrottier2021 | phonological_component_analysis | reviewer: michele
2026-05-06 | EXTRACTED | @Dronkers1996 | left_precentral_gyrus_insula | Lesion-overlap double dissociation: left precentral gyrus of insula necessary for apraxia of speech (n=44, 25 AoS vs 19 controls); 100% overlap in AoS group, 0% in controls; Talairach -41,-2,10 | annotation: 8/8 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Lazar2010 | initial_aphasia_severity | Initial WAB composite (WABinitial, 0-30) predicts 81% of variance in 90-day aphasia change (R2=0.81, p<0.001); proportional recovery 0.73 of maximal potential regardless of therapy (n=21, mild-moderate aphasia) | annotation: 7/7 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Pedersen2004 | stroke_severity_sss | Initial WAB-AQ + modified SSS predict R2=0.60 of 1-year WAB-AQ; WAB-AQ alone R2=0.47; age, sex, aphasia type not significant (n=203 first-ever stroke, Copenhagen Aphasia Study) | annotation: 12/12 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Leff2009 | left_superior_temporal_gyrus__Leff2009 | n=210 UCL stroke cohort; VBM (VBCM) identifies left posterior STG/STS [-66,-32,4] as shared substrate for auditory STM (digit span) and spoken sentence comprehension; 2 findings | annotation: 8/9 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @DenOuden2019 | syntactic_processing (impairment) | n=71 LH stroke (68 LSM); VLSM+CLSM; 3 findings: f1 left IFG pars triangularis (BA45) → morphosyntactic production deficit (causal, VLSM, lesion-size controlled); f2 left pSTG/angular gyrus → verb argument structure production deficit (causal, VLSM, k=47); f3 ventral IFG-temporal connectivity → noncanonical sentence production (correlational, CLSM, not lesion-size corrected) | COHORT_OVERLAP: USC/MUSC; overlaps @Fridriksson2018 @Yourganov2015Predicting @Basilakos2015 | annotation: 11/11 (100%) | schema: 0 issues | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Basilakos2015 | left_precentral_gyrus (region) | n=43 chronic LH stroke, USC cohort; VLSM (continuous T1-signal); 2 findings: f1 left precentral/postcentral gyrus → AOS-specific errors (causal, 2508 voxels); f2 left temporal/inferior prefrontal → aphasia-related speech errors (causal, dissociated from AOS) | Refutes Dronkers (1996) insula localization; no insula prediction of AOS | COHORT_OVERLAP: USC/MUSC | annotation: 8/8 (100%) | schema: 0 issues | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Itabashi2015 | left_precentral_gyrus (region) | n=136 acute/subacute LH MCA stroke (Kohnan Hospital, Japan); VLSM (Liebermeister); 2 findings: f1 left precentral gyrus posterior wall → pure AOS (causal, Z_max=3.482); f2 basal ganglia/corona radiata/precentral → AOS+aphasia (causal, larger lesion burden) | Independent replication of @Basilakos2015 in acute Japanese cohort | NO cohort overlap with USC papers | annotation: 8/8 (100%) | schema: 0 issues | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Robson2014 | left_anterior_temporal_lobe__Robson2014 | n=12 chronic Wernicke's aphasia; distortion-corrected fMRI reveals left ATL overactivation (anterior fusiform, temporal pole) + right aSTG for written words as residual comprehension substrate; 2 findings | annotation: 5/9 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED | @Naeser2005 | tms_right_ifg__Naeser2005 | n=4 open-protocol; 1Hz rTMS to right pars triangularis (BA45) for 10 days; significant BNT improvement at 2mo (p=0.003) lasting at 8mo in 3/4; 1 finding | annotation: 3/6 | agent: claude-sonnet-4-6
2026-05-06 | AUTO-APPROVED | @Lazar2010 | initial_aphasia_severity | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Dronkers1996 | left_precentral_gyrus_insula | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @Basilakos2015 | left_precentral_gyrus | reviewer: auto-reviewer
2026-05-06 | AUTO-APPROVED | @DenOuden2019 | syntactic_processing | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Pedersen2004 | stroke_severity_sss | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Robson2014 | left_anterior_temporal_lobe | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Itabashi2015 | left_precentral_gyrus | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Leff2009 | left_superior_temporal_gyrus | reviewer: claude-cowork
2026-05-06 | AUTO-APPROVED | @Naeser2005 | tms_right_ifg__Naeser2005 | reviewer: claude-cowork
2026-05-07 | EXTRACTED_REVIEW | @Raymer | constraint_induced_language_therapy | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Shekari2022 | aphasia_therapy_neuroplasticity_fmri | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Simic2023 | treatment_neuroplasticity_aphasia | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Watila2015 | aphasia_prognosis_predictors | 3 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-07 | EXTRACTED_REVIEW | @Wilson2021 | neuroplasticity_poststroke_aphasia | 4 findings | annotation: 12/12 | agent: claude-sonnet-4-6
2026-05-06 | EXTRACTED_REVIEW | @NadeauCrosson1997 | subcortical_aphasia | 4 findings | annotation: 12/12 | agent: claude-sonnet-4-6
2026-05-06 | RE-EXTRACTED_AS_REVIEW | @NadeauCrosson1997 | previously REFUSED 2026-05-06; re-extracted under schema v2.4 narrative_review conventions; draft: drafts/reviews/subcortical_aphasia__NadeauCrosson1997.md
2026-05-06 | EXTRACTED_REVIEW | @Radanovic2017 | basal_ganglia_aphasia | 4 findings | annotation: 9/9 | agent: claude-sonnet-4-6
2026-05-06 | RE-EXTRACTED_AS_REVIEW | @Radanovic2017 | previously REFUSED 2026-05-06; re-extracted under schema v2.4 narrative_review conventions; draft: drafts/reviews/basal_ganglia_aphasia__Radanovic2017.md
2026-05-06 | EXTRACTED_REVIEW | @Crosson1999 | thalamic_language_mechanisms | 3 findings | annotation: 8/8 | agent: claude-sonnet-4-6
2026-05-06 | RE-EXTRACTED_AS_REVIEW | @Crosson1999 | previously REFUSED 2026-05-06; re-extracted under schema v2.4 narrative_review conventions; draft: drafts/reviews/thalamic_language_mechanisms__Crosson1999.md
2026-05-06 | EXTRACTED_REVIEW | @MirmanThye2018 | lsm_language_systems_review | 4 findings | annotation: 11/11 | agent: claude-sonnet-4-6
2026-05-07 | IDENTIFIED-VIA-OCR | @Goldenberg1994 | 1-s2.0-S0093934X84710637-main.pdf -> Goldenberg1994.pdf | OCR via tesseract 4.1.1 + ocrmypdf 16.13.0 (4 pages, ~10s, 100% text recovery on title page). Resolves the 2026-05-06 FLAGGED entry. Paper: Goldenberg G, Spatt J. (1994). Influence of size and site of cerebral lesions on spontaneous recovery of aphasia and on success of language therapy. Brain Lang 47(4):684-698. doi:10.1006/brln.1994.1067. Filename's "84" is an Elsevier internal sequence, NOT the year. Searchable PDF (image+invisible OCR layer, PDF/A-2b) saved at papers/Goldenberg1994.pdf. Citation added to citations.md as [cited] (referenced as primary in drafts/reviews/aphasia_prognosis_predictors__Watila2015.md). Original publisher-named PDF could not be deleted from sandbox due to ACL — user can rm on their Mac.
2026-05-07 | APPROVED | @DenOuden2019 | syntactic_processing | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Pedersen2004 | stroke_severity_sss | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Robson2014 | left_anterior_temporal_lobe__Robson2014 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Itabashi2015 | left_precentral_gyrus | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Leff2009 | left_superior_temporal_gyrus__Leff2009 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | APPROVED | @Naeser2005 | tms_right_ifg__Naeser2005 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | AUTO-APPROVED | @Goldenberg1994 | lesion_volume__Goldenberg1994 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | AUTO-APPROVED | @Goldenberg1994 | left_temporobasal__Goldenberg1994 | reviewer: cowork-claude:sonnet-4-6
2026-05-07 | AUTO-APPROVED | @Watila2015 | aphasia_prognosis_predictors__Watila2015 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Shekari2022 | aphasia_therapy_neuroplasticity_fmri__Shekari2022 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Radanovic2017 | basal_ganglia_aphasia__Radanovic2017 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Raymer | constraint_induced_language_therapy__Raymer | reviewer: michele
2026-05-07 | AUTO-APPROVED | @MirmanThye2018 | lsm_language_systems_review__MirmanThye2018 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Wilson2021 | neuroplasticity_poststroke_aphasia__Wilson2021 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @NadeauCrosson1997 | subcortical_aphasia__NadeauCrosson1997 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Crosson1999 | thalamic_language_mechanisms__Crosson1999 | reviewer: michele
2026-05-07 | AUTO-APPROVED | @Simic2023 | treatment_neuroplasticity_aphasia__Simic2023 | reviewer: michele
2026-10-16 | LEGACY-TAGGED | — | 33 entries | review_tier: legacy stamped per GOVERNANCE.md §5
2026-10-19 | EXTRACTED | @Basilakos2019 | leukoaraiosis, lesion_volume, severity_metric | 3 predictor drafts; confidence: high
2026-10-19 | EXTRACTED | @Boyle2004 | semantic_feature_analysis | 1 therapy draft, 4 findings
2026-10-19 | EXTRACTED | @Breier2008 | left_arcuate_fasciculus, left_superior_longitudinal_fasciculus, left_uncinate_fasciculus | 3 drafts, confidence: high
2026-10-20 | EXTRACTED | @Buchsbaum2011 | left_posterior_planum_temporale_spt | Lesion overlap and aggregate fMRI link area Spt to conduction aphasia.
2026-10-20 | EXTRACTED | @DeWitt2012 | left_superior_temporal_gyrus, left_superior_temporal_sulcus | 2 drafts, 3 findings, confidence: high
2026-10-20 | EXTRACTED | @Fridriksson2010 | left_arcuate_fasciculus, left_supramarginal_gyrus, left_temporoparietal_junction, left_ifg_pars_opercularis | 4 findings
2026-10-20 | EXTRACTED | @Geschwind1965 | left_angular_gyrus, left_superior_temporal_gyrus_wernicke, corpus_callosum, disconnexion_syndromes | Theoretical synthesis of disconnexion syndromes.
2026-10-20 | EXTRACTED | @Hope2017 | right_middle_temporal_gyrus, right_precentral_gyrus, anomic_aphasia, lesion_volume, age, time_post_onset | 6 drafts, confidence: high
2026-10-20 | EXTRACTED | @Hosomi2009 | left_arcuate_fasciculus | AF fiber asymmetry predicts aphasia at discharge
2026-10-20 | EXTRACTED | @Pflugshaupt2009 | left_fusiform_gyrus, left_occipito_temporal_sulcus, left_inferior_temporal_gyrus, pure_alexia | 4 drafts, confidence: high
2026-10-20 | EXTRACTED | @Schwartz2009 | left_anterior_temporal_lobe, left_middle_temporal_gyrus, left_ifg_pars_triangularis, left_superior_temporal_gyrus_wernicke | VLSM study on semantic naming errors (n=64).
2026-10-20 | EXTRACTED | @Schwartz2012 | left_precentral_gyrus, left_supramarginal_gyrus, left_arcuate_fasciculus, left_posterior_stg | VLSM of phonological errors in naming
2026-10-20 | EXTRACTED | @Rapcsak2009 | left_ifg_pars_opercularis, left_precentral_gyrus, left_superior_temporal_gyrus, left_supramarginal_gyrus, left_insula, severity_metric | Distributed perisylvian network associated with phonological dyslexia/dysgraphia; anterior regions correlate with reading lexicality effect; PC score predicts written language performance.
2026-10-20 | EXTRACTED | @Baldo2011 | left_precentral_gyrus_insula | VLSM study on complex articulation (n=33)
2026-10-20 | EXTRACTED | @Karnath2018 | lesion_volume, initial_aphasia_severity | synthesis of predictor consensus
2026-10-20 | EXTRACTED | @Fridriksson2010Anomia | left_middle_temporal_gyrus, left_ifg_pars_opercularis, left_precentral_gyrus, bilateral_middle_frontal_gyrus_recovery, left_supramarginal_gyrus_premotor | 5 findings across 5 region drafts
2026-10-20 | EXTRACTED | @Alyahya2020 | 8 drafts | confidence: high | details: VBCM mapping of 7 PCA components to LH lesions
2026-10-20 | EXTRACTED | @Bates2003 | left_precentral_gyrus_insula, left_arcuate_fasciculus_slf, left_middle_temporal_gyrus, left_ifg_pars_opercularis, left_dorsolateral_prefrontal_cortex, left_parietal_association_cortex | VLSM analysis of fluency and comprehension in n=101 patients.
2026-10-20 | EXTRACTED | @Benghanem2019 | severity_metric, lesion_volume, left_temporoparietal_junction | 3 drafts, confidence: high
2026-10-20 | EXTRACTED | @Benjamin2014 | right_lateral_frontal_cortex, right_medial_frontal_cortex, right_posterior_perisylvian_cortex, intention_treatment | 4 drafts, confidence: high
2026-10-20 | EXTRACTED | @Bhogal2003 | therapy_intensity | Meta-analysis of 10 studies linking therapy intensity to PICA and Token Test improvement.
2026-10-20 | EXTRACTED | @Billot2022 | severity_metric, rs_fmri_connectivity, structural_integrity | 3 drafts, 4 findings, confidence: high
2026-10-20 | EXTRACTED | @Binder2009 | left_angular_gyrus, left_middle_temporal_gyrus, left_ifg_pars_orbitalis, left_dorsomedial_prefrontal_cortex, left_posterior_cingulate_gyrus, left_fusiform_gyrus, left_superior_temporal_sulcus | 7 drafts, recruitment findings from ALE meta-analysis
2026-10-20 | EXTRACTED | @Bonilha2016 | left_temporal_lobe, global_network_small_worldness, severity_metric, lesion_volume | 4 drafts
2026-10-20 | EXTRACTED | @Breitenstein2017 | intensive_speech_and_language_therapy, stroke_severity_sss | 4 findings, RCT, n=156
2026-10-20 | EXTRACTED | @Brookshire2014 | alexia, severity_metric, education | 4 findings
2026-10-20 | EXTRACTED | @Butler2014 | left_posterior_stg, left_arcuate_fasciculus, left_ifg_pars_opercularis, left_anterior_temporal_lobe, left_extreme_capsule, executive_functions | VBCM analysis of PCA factors
2026-10-20 | EXTRACTED | @Catani2008 | left_arcuate_fasciculus, left_uncinate_fasciculus, left_inferior_longitudinal_fasciculus, left_inferior_fronto_occipital_fasciculus | 4 drafts, confidence: high
2026-10-20 | EXTRACTED | @Dick2012 | left_arcuate_fasciculus, left_extreme_capsule, left_uncinate_fasciculus, left_middle_longitudinal_fasciculus, left_inferior_fronto_occipital_fasciculus | 5 region-anchored drafts using method: narrative_review
2026-10-21 | EXTRACTED | @Dronkers2004 | left_middle_temporal_gyrus, left_superior_temporal_gyrus, left_angular_gyrus, left_middle_frontal_gyrus, left_ifg_pars_triangularis, left_ifg_pars_opercularis, left_superior_temporal_gyrus_wernicke | VLSM mapping of sentence comprehension (n=64)
2026-10-21 | EXTRACTED | @Efstratiadou2018 | typicality_semantic_feature_analysis_review | 5 findings from systematic review
2026-10-21 | EXTRACTED | @Forkel2014 | right_arcuate_fasciculus, lesion_volume, age | 3 drafts, confidence: high
2026-10-21 | EXTRACTED | @Fridriksson2013 | left_anterior_arcuate_fasciculus, left_uncinate_fasciculus, left_inferior_longitudinal_fasciculus, left_precentral_gyrus | VBCM analysis of 64 chronic LH stroke patients
2026-10-21 | EXTRACTED | @Fridriksson2018JAMA | tdcs_aphasia_treatment, severity_metric | RCT on A-tDCS for naming; baseline AQ as predictor.
2026-10-21 | EXTRACTED | @GajardoVidal2021 | left_anterior_arcuate_fasciculus, left_ifg_pars_opercularis, left_ifg_pars_triangularis | aAF is the sole predictor of long-term speech production; BA44/45 have no unique effect.
2026-10-21 | EXTRACTED | @Griffis2017 | left_posterior_temporal_bottleneck, left_anterior_prefrontal_bottleneck, left_posterior_middle_temporal_white_matter | 3 drafts, 8 findings
2026-10-21 | EXTRACTED | @Halai2017 | left_superior_temporal_gyrus, left_anterior_temporal_lobe, left_precentral_gyrus, left_frontal_aslant_tract | VBCM analysis of 31 chronic aphasia patients
2026-10-20 | EXTRACTED | @Hartwigsen2019 | language_recovery_dynamics | narrative review synthesis of recovery phases and network reorganization
2026-10-21 | EXTRACTED | @Henseler2014 | left_ifg_pars_opercularis, left_superior_temporal_gyrus_wernickes, left_precentral_gyrus_insula, left_supramarginal_gyrus_premotor, left_superior_temporal_gyrus, left_middle_temporal_gyrus, left_anterior_temporal_lobe, left_angular_gyrus | 8 findings extracted via VLSM
2026-10-21 | EXTRACTED | @Hillis2004 | left_precentral_gyrus_insula, left_ifg_pars_opercularis, left_postcentral_gyrus | 3 drafts, confidence: high
2026-10-21 | EXTRACTED | @Hope2013 | lesion_volume, time_post_onset, left_superior_temporal_gyrus_wernicke, left_ifg_pars_opercularis, left_arcuate_fasciculus, severity_metric | GPR model predicting speech production recovery
2026-10-20 | REKEYED | @Rapcsak2009 | was extracted as @1-s2.0-S0010945208001330-main (PDF had no citations.md entry)
2026-10-20 | REKEYED | @Karnath2018 | was extracted as @1-s2.0-S1053811917308558-main (PDF had no citations.md entry)
2026-10-20 | REKEYED | @Fridriksson2010Anomia | was extracted as @11558.full (PDF had no citations.md entry)
2026-10-20 | REKEYED | @Bates2003 | was extracted as @Bates-et-al-Nature-Neuroscience-2003 (PDF had no citations.md entry)
2026-10-21 | EXTRACTED | @Efstratiadou2018 | typicality_semantic_feature_analysis | systematic review of SFA efficacy (n=55)
2026-10-21 | EXTRACTED | @Hartwigsen2019 | neuroplasticity_language_network, severity_metric | Narrative review of neuroimaging in aphasia recovery
2026-10-21 | EXTRACTED | @Hickok2007 | dual_stream_speech_processing | synthesis of dual-stream framework
2026-10-21 | EXTRACTED | @Hope2018 | imaging_metric_structural_disconnection | No unique prognostic value for connectivity over lesion load
2026-10-21 | EXTRACTED | @Kasdan2025 | left_posterior_stg, rhythm_production | VLSM and behavioral correlations linking rhythm tapping to left temporoparietal damage and language production.
2026-10-21 | EXTRACTED | @Kristinsson2021 | lesion_volume, severity_metric | Multimodal SVR prediction of WAB scores
2026-10-21 | EXTRACTED | @Kummerer2013 | left_arcuate_fasciculus_slf, left_extreme_capsule | VLSM of acute stroke patients (n=100) showing dorsal-ventral dissociation.
2026-10-21 | EXTRACTED | @Laver2025 | virtual_reality_rehabilitation | 5 findings extracted from systematic review
2026-10-21 | EXTRACTED | @Leonard2008 | phonological_component_analysis, severity_metric | 2 drafts
2026-10-21 | EXTRACTED | @Matchin2020 | left_ifg_pars_triangularis, left_posterior_stg | double dissociation of agrammatism/paragrammatism
2026-10-21 | EXTRACTED | @Meinzer2010 | left_hippocampus | hippocampal volume and FA predict naming therapy response
2026-10-21 | EXTRACTED | @Mitchell2017 | dysarthria_interventions | Systematic review of 5 RCTs on dysarthria interventions; found immediate but not persisting effects on impairment.
2026-10-21 | EXTRACTED | @Plowman2012 | aphasia_prognosis_predictors__Plowman2012 | Narrative review of patient and stroke-related prognostic factors.
2026-10-21 | EXTRACTED | @Saur2006 | right_ifg_pars_triangularis, left_ifg_pars_triangularis | 2 region-anchored drafts
2026-10-21 | EXTRACTED | @Stockert2020 | left_ifg_pars_triangularis, right_dlpfc | longitudinal fMRI study on lesion-specific reorganization
2026-10-21 | EXTRACTED | @Thiel2013 | tms_right_ifg, left_superior_temporal_gyrus | 2 drafts, confidence: high
2026-10-21 | EXTRACTED | @Thompson2003 | treatment_of_underlying_forms | CATE hypothesis: complex-to-simple generalization
2026-10-21 | EXTRACTED | @Thye2018 | lesion_volume, left_heschls_gyrus | 2 drafts
2026-10-21 | EXTRACTED | @Turkeltaub2011 | right_ifg_pars_opercularis, right_ifg_pars_triangularis | ALE meta-analysis of 105 patients; dissociated RH POp (homologous/compensatory) from RH PTr (non-homologous/dysfunctional).
2026-10-21 | EXTRACTED | @Wilson2019 | language_mapping_methods | Review of adaptive fMRI paradigms for language mapping in aphasia.
2026-10-21 | EXTRACTED | @WilsonHula2019 | multivariate_aphasia_approaches | narrative review of multivariate methods
2026-10-21 | EXTRACTED | @Zumbansen2014 | melodic_intonation_therapy_review | narrative review of MIT mechanisms and definitions
2026-10-21 | REKEYED | @Wallentin2018 | was extracted as @Wallentin (PDF had no citations.md entry)
2026-10-21 | EXTRACTED | @Ivanova2016 | left_arcuate_fasciculus, left_inferior_frontal_occipital_fasciculus, left_inferior_longitudinal_fasciculus | DTI correlations between tract integrity and language scores
2026-10-21 | EXTRACTED | @Rogalsky2018 | left_posterior_stg, left_ifg_pars_opercularis, left_anterior_temporal_lobe | VLSM study on 66 chronic LH patients; implicates posterior STG/parietal in agrammatism, not Broca's area.
2026-10-21 | EXTRACTED | @Yourganov2016 | left_posterior_stg, left_ifg_pars_opercularis, lesion_volume | Multivariate SVR prediction of WAB scores from lesions and connectomes.
2026-10-21 | EXTRACTED | @vanderMeulen2014 | melodic_intonation_therapy, time_post_onset | RCT on subacute severe nonfluent aphasia (n=27)
2026-10-21 | EXTRACTED | @Brady2022 | age, severity_metric, time_post_onset, sex | IPD network meta-analysis of 959 participants across 25 RCTs.
2026-10-21 | EXTRACTED | @Mohr2017 | neuroplasticity_intensive_therapy | narrative review of intensive therapy effects
2026-10-21 | EXTRACTED | @Wallentin2018 | sex, age | Meta-analysis (n=48k) and database query (n=1.9M) on sex differences in aphasia rates.
2026-10-21 | EXTRACTED | @Corbetta2015 | left_posterior_stg, lesion_volume | Ridge regression mapping of behavioral clusters to anatomy
2026-10-21 | EXTRACTED | @Godecke2021 | intensive_aphasia_therapy | High-powered RCT showing no significant benefit of early intensive therapy over usual care at 12 weeks.
2026-10-21 | EXTRACTED | @Hillis2001 | left_superior_temporal_gyrus_wernickes | Correlational link between BA22 hypoperfusion and semantic deficit severity (n=50).
2026-10-21 | EXTRACTED | @Hillis2006 | left_middle_temporal_gyrus, left_ifg_pars_opercularis, left_superior_temporal_gyrus_wernicke | 3 region-anchored drafts
2026-10-21 | EXTRACTED | @Johnson2019 | age, severity_metric | LME analysis of chronic aphasia progression
2026-10-21 | EXTRACTED | @Laska2001 | age, severity_metric, lesion_volume | 3 predictor drafts
2026-10-21 | EXTRACTED | @Lazar2008 | initial_aphasia_severity, lesion_volume | 2 predictor drafts
2026-10-21 | EXTRACTED | @Nouwens2017 | cognitive_linguistic_treatment | RCT showing no effect of early intensive CLT on ANELT-A scores
2026-10-21 | EXTRACTED | @Ochfeld2010 | left_ifg_pars_opercularis | 3 findings: acute association, chronic dissociation, longitudinal resolution
2026-10-21 | EXTRACTED | @Pedersen1995 | initial_aphasia_severity, age | n=881 acute stroke; initial severity predicts outcome; age does not.
2026-10-21 | EXTRACTED | @Ramsey2017 | left_arcuate_fasciculus, severity_metric, education | 3 drafts
2026-10-21 | EXTRACTED | @Wilson2023 | severity_metric, left_posterior_stg | longitudinal cohort n=218, recovery trajectories by lesion group
2026-10-21 | EXTRACTED | @Baldo2013 | left_middle_temporal_gyrus, left_superior_temporal_gyrus | VLSM analysis of BNT naming with and without covariates
2026-10-21 | EXTRACTED | @Fritsch2022 | thalamic_aphasia | narrative review of phenotypes and mechanisms
2026-10-21 | EXTRACTED | @Han2013 | left_inferior_fronto_occipital_fasciculus, left_anterior_thalamic_radiation, left_uncinate_fasciculus | 3 region-anchored drafts
2026-10-21 | EXTRACTED | @Li2017 | left_anterior_thalamic_radiation, left_inferior_fronto_occipital_fasciculus, left_uncinate_fasciculus, left_arcuate_fasciculus_slf, left_frontal_aslant_tract | 5 region drafts, 6 findings
2026-10-21 | EXTRACTED | @Oeckel2021 | left_extreme_capsule, left_arcuate_fasciculus | 2 region-anchored drafts
2026-10-21 | EXTRACTED | @Sebastian2014 | left_thalamus, right_thalamus | 2 region-anchored drafts
2026-10-21 | EXTRACTED | @Siegel2016 | severity_metric, left_hemisphere_intrahemispheric_connectivity | 2 drafts, confidence: high
2026-10-21 | EXTRACTED | @Xing2016 | right_superior_temporal_gyrus, right_supramarginal_gyrus | VBM study on n=32 chronic aphasia patients showing RH temporoparietal GM volume predicts AQ and production.
2026-10-22 | MODEL-APPROVED | @Rogalsky2018 | left_anterior_temporal_lobe | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Johnson2019 | age | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Laska2001 | lesion_volume | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Laska2001 | severity_metric | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Bates2003 | left_ifg_pars_opercularis | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Butler2014 | left_ifg_pars_opercularis | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Henseler2014 | left_ifg_pars_opercularis | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Yourganov2016 | left_ifg_pars_opercularis | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Henseler2014 | left_middle_temporal_gyrus | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Fridriksson2013 | left_precentral_gyrus | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Henseler2014 | left_precentral_gyrus_insula | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Henseler2014 | left_superior_temporal_gyrus | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Schwartz2009 | left_superior_temporal_gyrus_wernicke | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Henseler2014 | left_superior_temporal_gyrus_wernickes | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Henseler2014 | left_supramarginal_gyrus_premotor | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | REKEYED | @Oeckel2021 | was extracted as @MartinezOeckel2021 (PDF had no citations.md entry)
2026-10-22 | RE-EXTRACTED | @Maher2006 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Pulvermuller2001 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Schlaug2008 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Stahl2013 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @vanderMeulen2012 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | EXTRACTED | @Maher2006 | constraint_induced_aphasia_therapy | CILT efficacy on WAB-AQ and narrative discourse in chronic aphasia
2026-10-22 | EXTRACTED | @Pulvermuller2001 | constraint_induced_aphasia_therapy | 1 draft, 2 findings
2026-10-22 | EXTRACTED | @Schlaug2008 | melodic_intonation_therapy | behavioral and fMRI effects of MIT vs SRT in n=2
2026-10-22 | EXTRACTED | @Stahl2013 | melodic_intonation_therapy | comparative efficacy of singing vs rhythmic therapy
2026-10-22 | EXTRACTED | @vanderMeulen2012 | melodic_intonation_therapy_review | narrative review of MIT efficacy and mechanisms
2026-10-22 | RE-EXTRACTED | @Breier2008 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Schwartz2012 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Karnath2018 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Alyahya2020 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Benghanem2019 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Billot2022 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Bonilha2016 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Breitenstein2017 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Catani2008 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Griffis2017 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Halai2017 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | RE-EXTRACTED | @Hope2013 | previous drafts moved to _compare/superseded/2026-10-22/ | current extractor (thinking off)
2026-10-22 | EXTRACTED | @Breier2008 | left_arcuate_fasciculus, left_superior_longitudinal_fasciculus | DTI study (n=20) linking FA values of AF/SLF to repetition and comprehension.
2026-10-22 | EXTRACTED | @Schwartz2012 | left_supramarginal_gyrus, left_precentral_gyrus, left_ifg_pars_opercularis | VLSM of phonological errors in naming
2026-10-22 | EXTRACTED | @Karnath2018 | lesion_behavior_mapping_methods | Narrative review of VLBM and MLBM methods
2026-10-22 | EXTRACTED | @Alyahya2020 | left_ifg_pars_opercularis, left_middle_frontal_gyrus, left_arcuate_fasciculus | VBCM analysis of connected speech components in chronic aphasia.
2026-10-22 | EXTRACTED | @Benghanem2019 | initial_aphasia_severity, lesion_volume, left_temporoparietal_junction | 3 drafts
2026-10-22 | EXTRACTED | @Billot2022 | severity_metric, imaging_metric_rsfc | Multimodal ML prediction of treatment response (n=55)
2026-10-22 | EXTRACTED | @Bonilha2016 | severity_metric, left_temporal_lobe, global_structural_network | 3 drafts
2026-10-22 | EXTRACTED | @Breitenstein2017 | intensive_speech_and_language_therapy, severity_metric | RCT on intensive SLT (n=156) showing improved verbal communication (ANELT A-scale) and mRS as a predictor.
2026-10-22 | EXTRACTED | @Catani2008 | arcuate_fasciculus_disconnection | narrative review of AF anatomy and disconnection paradigm
2026-10-22 | EXTRACTED | @Griffis2017 | left_frontal_white_matter_bottleneck, left_posterior_temporal_white_matter_bottleneck | ROI-based regression and SVR-LSM showing bottleneck effects beyond tract/cortical load
2026-10-22 | EXTRACTED | @Halai2017 | left_precentral_gyrus, left_superior_temporal_gyrus, left_anterior_temporal_lobe | VBCM analysis of PCA factors
2026-10-22 | EXTRACTED | @Hope2013 | lesion_volume, time_post_onset | GPR-based prediction of speech production in n=270 patients
2026-10-22 | MODEL-APPROVED | @Bonilha2016 | severity_metric | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-22 | MODEL-APPROVED | @Griffis2017 | left_frontal_white_matter_bottleneck | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-23 | EXTRACTED | @Biesbroek2017 | cerebral_small_vessel_disease_cognition | narrative review of SVD lesion location and cognition
2026-10-23 | EXTRACTED | @Brownsett2014 | left_dorsal_anterior_cingulate_cortex | f1: dACC/SFG activity correlates with communicative ability
2026-10-23 | EXTRACTED | @Cote2007 | right_hemisphere_communication_profiles | 1 draft, 2 findings
2026-10-23 | EXTRACTED | @Durfee2021 | affective_prosody_localization | Systematic review of RH prosody localization
2026-10-23 | EXTRACTED | @ElHachioui2013 | severity_metric, age | longitudinal cohort, n=130, phonology as strongest linguistic predictor
2026-10-23 | EXTRACTED | @Geranmayeh2017 | left_presma_dacc, severity_metric | longitudinal fMRI and behavioral prediction of recovery
2026-10-23 | EXTRACTED | @Gilmore2019 | executive_functions, severity_metric | Predictors of PMG and PMGM in naming and sentence therapy
2026-10-23 | EXTRACTED | @Glascher2012 | left_rostral_anterior_cingulate_cortex, left_middle_frontal_gyrus, left_ventromedial_prefrontal_cortex | 3 drafts
2026-10-23 | EXTRACTED | @Lacey2017 | left_ifg_pars_opercularis, left_superior_temporal_gyrus, left_supramarginal_gyrus, left_middle_frontal_gyrus | SVR-LSM on 38 chronic LH stroke patients
2026-10-23 | EXTRACTED | @Lukic2017 | right_middle_temporal_gyrus, right_supplementary_motor_area, right_insula | VBM/VLSM study on RH GM volume and language performance
2026-10-23 | EXTRACTED | @Munsch2016 | severity_metric, left_superior_temporal_gyrus | VLSM and logistic regression on 289 stroke patients
2026-10-23 | EXTRACTED | @Rodrigues2014 | recurring_utterances | behavioral profile and recovery of RU patients
2026-10-23 | EXTRACTED | @Ross2008 | right_frontal_operculum, right_temporal_operculum, right_thalamus | 3 region-anchored drafts
2026-10-23 | EXTRACTED | @Schumacher2019 | left_temporal_fusiform_cortex_posterior, left_middle_frontal_gyrus, lesion_volume | VBCM and correlation analysis of non-verbal cognitive components
2026-10-23 | EXTRACTED | @Sheppard2020 | right_posterior_stg, right_amygdala, age | Acute RH stroke cohort (n=23); RLSM identifying right posterior STG and amygdala as predictors of prosody deficits.
2026-10-23 | EXTRACTED | @Simic2019 | executive_functions | Systematic review of 15 studies on EC as a predictor of therapy success.
2026-10-23 | EXTRACTED | @SkipperKallal2017 | lesion_volume, right_motor_cortex | 2 drafts
2026-10-23 | EXTRACTED | @Zhao2018 | left_angular_gyrus, left_middle_temporal_gyrus | SVR-LSM and SVR-ROI analysis of 410 stroke patients
2026-10-23 | MODEL-APPROVED | @Schumacher2019 | lesion_volume | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-26 | BACKFILLED | @Alyahya2018NounVerb | cohort, lesion_mapping, phase | 99 value(s) written, 0 not (no quote found) across 33 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Alyahya2020 | cohort, lesion_mapping | 8 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Baldo2006 | cohort, lesion_mapping, phase | 6 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Baldo2011 | cohort, lesion_mapping | 2 value(s) written, 2 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Baldo2013 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Barbieri2023 | cohort, phase | 32 value(s) written, 0 not (no quote found) across 16 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Basilakos2015 | cohort, lesion_mapping, phase | 3 value(s) written, 3 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Basilakos2019 | cohort, lesion_mapping | 5 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Bates2003 | cohort, lesion_mapping | 4 value(s) written, 12 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Benghanem2019 | cohort, lesion_mapping | 5 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Benjamin2014 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Bhogal2003 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Billot2022 | cohort, lesion_mapping | 2 value(s) written, 2 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Binder2009 | cohort | 12 value(s) written, 0 not (no quote found) across 12 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Bonilha2014 | cohort, lesion_mapping, phase | 9 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Bonilha2016 | cohort | 1 value(s) written, 2 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Boyle2004 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Brady2022 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Breier2008 | cohort | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Breining2022 | cohort, lesion_mapping, phase | 2 value(s) written, 4 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Breitenstein2017 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Brookshire2014 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Brownsett2014 | cohort | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Buchsbaum2011 | cohort, lesion_mapping | 3 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Butler2014 | cohort, lesion_mapping | 4 value(s) written, 8 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Corbetta2015 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Cote2007 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @DenOuden2019 | cohort, lesion_mapping, phase | 18 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @DeWitt2012 | cohort | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Dresang2022 | cohort, phase | 12 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Dronkers1996 | cohort, lesion_mapping, phase | 3 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Dronkers2004 | cohort, lesion_mapping | 2 value(s) written, 12 not (no quote found) across 7 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @ElHachioui2013 | cohort | 1 value(s) written, 1 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Forkel2014 | cohort | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2010 | cohort, lesion_mapping | 4 value(s) written, 4 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2010Anomia | cohort, lesion_mapping | 6 value(s) written, 0 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2013 | cohort, lesion_mapping | 4 value(s) written, 6 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2018 | cohort, lesion_mapping, phase | 72 value(s) written, 0 not (no quote found) across 24 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2018Anatomy | cohort, lesion_mapping, phase | 24 value(s) written, 0 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2018BDNF | cohort, phase | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Fridriksson2018JAMA | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @GajardoVidal2021 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Geranmayeh2017 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Gilmore2019 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Glascher2012 | cohort, lesion_mapping | 1 value(s) written, 5 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Godecke2021 | cohort | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Goldenberg1994 | cohort, lesion_mapping, phase | 5 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Griffis2017 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Halai2017 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Han2013 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Harvey2022 | cohort, lesion_mapping, phase | 5 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Henseler2014 | cohort, lesion_mapping | 6 value(s) written, 10 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hillis2001 | cohort | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hillis2004 | cohort, lesion_mapping | 3 value(s) written, 3 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hillis2006 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hope2013 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hope2017 | cohort | 6 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hope2018 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hosomi2009 | cohort | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Hu2025 | cohort, phase | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Itabashi2015 | cohort, lesion_mapping, phase | 12 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Ivanova2016 | cohort | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Johnson2019 | cohort | 1 value(s) written, 1 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Kasdan2025 | cohort, lesion_mapping | 3 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Kristinsson2021 | cohort, lesion_mapping | 2 value(s) written, 1 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Kristinsson2025 | cohort, lesion_mapping, phase | 6 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Kummerer2013 | cohort, lesion_mapping | 2 value(s) written, 2 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Lacey2017 | cohort, lesion_mapping | 2 value(s) written, 6 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Laska2001 | cohort, lesion_mapping | 3 value(s) written, 1 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Laver2025 | cohort | 5 value(s) written, 0 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Lazar2008 | cohort | 1 value(s) written, 1 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Lazar2010 | cohort, phase | 2 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Leff2009 | cohort, lesion_mapping | 8 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Leonard2008 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Li2017 | cohort, lesion_mapping | 4 value(s) written, 8 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Lukic2017 | cohort, lesion_mapping | 2 value(s) written, 6 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Maher2006 | cohort, phase | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Marchina2011 | cohort, phase | 20 value(s) written, 0 not (no quote found) across 10 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @MassonTrottier2021 | cohort, phase | 8 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Matchin2020 | cohort, lesion_mapping | 2 value(s) written, 2 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Meinzer2010 | cohort, lesion_mapping | 2 value(s) written, 1 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Mirman2015 | cohort, lesion_mapping, phase | 14 value(s) written, 7 not (no quote found) across 7 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Munsch2016 | cohort, lesion_mapping | 6 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Naeser2005 | cohort, phase | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Nouwens2017 | cohort | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Ochfeld2010 | cohort, lesion_mapping | 4 value(s) written, 2 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Oeckel2021 | cohort, lesion_mapping | 2 value(s) written, 2 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Pedersen1995 | cohort | 1 value(s) written, 1 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Pedersen2004 | cohort, phase | 8 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Pflugshaupt2009 | cohort, lesion_mapping | 7 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Pulvermuller2001 | cohort, phase | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Ramsey2017 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Rapcsak2009 | cohort, lesion_mapping | 5 value(s) written, 10 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Robson2014 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Robson2019 | cohort, lesion_mapping, phase | 13 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Rodrigues2014 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Rogalsky2018 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Ross2008 | cohort, lesion_mapping | 8 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Saur2006 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Saur2008 | cohort, phase | 20 value(s) written, 0 not (no quote found) across 10 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Schlaug2008 | cohort, phase | 3 value(s) written, 1 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Schumacher2019 | cohort, lesion_mapping | 3 value(s) written, 2 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Schwartz2009 | cohort, lesion_mapping | 8 value(s) written, 2 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Schwartz2012 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Sebastian2014 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Sheppard2020 | cohort, lesion_mapping | 2 value(s) written, 4 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Baldo2011 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Basilakos2015 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Bates2003 | cohort, lesion_mapping | 12 value(s) written, 0 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Billot2022 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Bonilha2016 | cohort | 2 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Breining2022 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Butler2014 | cohort, lesion_mapping | 8 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Dronkers2004 | cohort, lesion_mapping | 12 value(s) written, 0 not (no quote found) across 7 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @ElHachioui2013 | cohort | 1 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Fridriksson2010 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Fridriksson2013 | cohort, lesion_mapping | 6 value(s) written, 0 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @GajardoVidal2021 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Glascher2012 | cohort, lesion_mapping | 2 value(s) written, 3 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Griffis2017 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Halai2017 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Han2013 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Henseler2014 | cohort, lesion_mapping | 10 value(s) written, 0 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Hillis2004 | cohort, lesion_mapping | 2 value(s) written, 1 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Hillis2006 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Johnson2019 | cohort | 1 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Kristinsson2021 | cohort | 1 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Kummerer2013 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Lacey2017 | cohort, lesion_mapping | 6 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Laska2001 | cohort | 1 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Lazar2008 | cohort | 1 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Li2017 | cohort, lesion_mapping | 8 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Lukic2017 | cohort, lesion_mapping | 6 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Matchin2020 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Meinzer2010 | cohort | 1 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Oeckel2021 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Pedersen1995 | cohort | 1 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Rapcsak2009 | cohort, lesion_mapping | 10 value(s) written, 0 not (no quote found) across 8 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Rogalsky2018 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Schumacher2019 | cohort, lesion_mapping | 2 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Schwartz2009 | lesion_mapping | 2 value(s) written, 0 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Schwartz2012 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILL-REAPPLIED | @Sheppard2020 | cohort, lesion_mapping | 4 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | BACKFILLED | @Siegel2016 | cohort, lesion_mapping | 3 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-26 | SCREEN-BACKFILL | — | screening register | 164 citations.md entries added as other-source candidates
2026-10-26 | RETARGETED | @Fridriksson2010Anomia | bilateral_middle_frontal_gyrus_recovery | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Henseler2014 | left_anterior_temporal_lobe | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Fridriksson2010Anomia | left_ifg_pars_opercularis | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hillis2006 | left_ifg_pars_opercularis | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Fridriksson2010Anomia | left_middle_temporal_gyrus | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hillis2006 | left_middle_temporal_gyrus | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Yourganov2016 | left_posterior_stg | f4 naming→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Fridriksson2010Anomia | left_precentral_gyrus | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hillis2006 | left_superior_temporal_gyrus_wernicke | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Fridriksson2010Anomia | left_supramarginal_gyrus_premotor | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hope2017 | right_middle_temporal_gyrus | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @SkipperKallal2017 | right_motor_cortex | f1 naming→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hope2017 | right_precentral_gyrus | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Marchina2011 | left_arcuate_fasciculus | f4 confrontation_naming→anomia; f9 confrontation_naming→anomia | symptom not syndrome (schema v2.8); canonical | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Bonilha2014 | left_ifg_pars_triangularis | f1 naming→anomia | symptom not syndrome (schema v2.8); canonical | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Saur2008 | left_middle_temporal_gyrus | f2 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); canonical | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Fridriksson2018Anatomy | left_posterior_stg | f3 naming→anomia; f7 naming→anomia | symptom not syndrome (schema v2.8); canonical | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hope2017 | anomic_aphasia | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Leonard2008 | phonological_component_analysis | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Fridriksson2018JAMA | tdcs_aphasia_treatment | f1 naming→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Efstratiadou2018 | typicality_semantic_feature_analysis | f2 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hope2017 | age | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Gilmore2019 | executive_functions | f1 naming→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hope2017 | lesion_volume | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | @Hope2017 | time_post_onset | f1 anomic_aphasia→anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | intensive_aphasia_therapy | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | intensive_speech_and_language_therapy | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | intention_treatment | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | phonological_component_analysis | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | semantic_feature_analysis | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | tdcs_aphasia_treatment | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | typicality_semantic_feature_analysis | targets_impairments += anomia | symptom not syndrome (schema v2.8); draft | tool: retarget_symptoms.py
2026-10-26 | RETARGETED | — | constraint_induced_aphasia_therapy | targets_impairments += anomia | symptom not syndrome (schema v2.8); canonical | tool: retarget_symptoms.py
2026-10-27 | BACKFILLED | @Barbieri2023 | therapy | 16 value(s) written, 0 not (no quote found) across 16 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Benjamin2014 | therapy | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Bonilha2016 | therapy | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Boyle2004 | therapy | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Brady2022 | therapy | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Breitenstein2017 | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Fridriksson2010Anomia | therapy | 5 value(s) written, 0 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Fridriksson2018BDNF | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Fridriksson2018JAMA | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Gilmore2019 | therapy | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Godecke2021 | therapy | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Goldenberg1994 | therapy | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Laver2025 | therapy | 5 value(s) written, 0 not (no quote found) across 5 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Leonard2008 | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Meinzer2010 | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Naeser2005 | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Nouwens2017 | therapy | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Pulvermuller2001 | therapy | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Schlaug2008 | therapy | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @Thiel2013 | therapy | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | @vanderMeulen2012 | therapy | 1 value(s) written, 0 not (no quote found) across 1 finding(s) | model: gemma4:31b-it-q8_0
2026-10-27 | BACKFILLED | — | treatment_of_underlying_forms | therapy | 1 finding(s) filled from the therapy entry itself | tool: backfill.py
2026-10-27 | BACKFILLED | — | treatment_of_underlying_forms | therapy | 1 finding(s) filled from the therapy entry itself | tool: backfill.py
2026-10-27 | BACKFILLED | — | typicality_semantic_feature_analysis | therapy | 1 finding(s) filled from the therapy entry itself | tool: backfill.py
2026-10-27 | BACKFILLED | — | constraint_induced_aphasia_therapy | therapy | 1 finding(s) filled from the therapy entry itself | tool: backfill.py
2026-10-27 | BACKFILLED | — | melodic_intonation_therapy | therapy | 1 finding(s) filled from the therapy entry itself | tool: backfill.py
2026-10-27 | BACKFILLED | — | phonological_component_analysis | therapy | 4 finding(s) filled from the therapy entry itself | tool: backfill.py
2026-10-27 | APPROVED | ? | anomia | reviewer: human:michele | tier: B
2026-10-27 | SCREEN-REBASELINE | — | screening register | 152 legacy decisions moved to `legacy` | benchmark 151 | protocol bf2a8e24bc92
2026-10-27 | SEARCHED | — | S001 pubmed | 4465 records | 4375 new candidates (register 164→4539) | strategy q1_lesion_impairment v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S002 pubmed | 2145 records | 1380 new candidates (register 4539→5919) | strategy q1b_language_lesion_mapping v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S003 pubmed | 1041 records | 680 new candidates (register 5919→6599) | strategy q1c_cognition_prosody_lesion v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S004 pubmed | 2375 records | 2065 new candidates (register 6599→8664) | strategy q2a_therapy_efficacy v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S005 pubmed | 2864 records | 443 new candidates (register 8664→9107) | strategy q2b_therapy_response_neural v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S006 pubmed | 4037 records | 1415 new candidates (register 9107→10522) | strategy q3_predictor_outcome v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S007 pubmed | 1704 records | 543 new candidates (register 10522→11065) | strategy q4_synthesis v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S008 pubmed | 908 records | 829 new candidates (register 11065→11894) | strategy q5_recruitment_meta v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S009 openalex | 6236 records | 3206 new candidates (register 11894→15100) | strategy q1_lesion_impairment v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCHED | — | S010 scopus | 98 records | 71 new candidates (register 15100→15171) | strategy q1_lesion_impairment v1 bf2a8e24bc92 | by: michele
2026-10-27 | SEARCH-WITHDRAWN | — | S010 | Scopus export held 98 records, not the full result set | 71 candidates removed | by: michele
2026-10-27 | SCREEN-RESET | — | screening register | pilot searches S001–S010 under protocol v1 (PubMed q1–q5, OpenAlex q1, Scopus q1 partial) set aside before any screening; register restored to its pre-lock state (164 legacy candidates); protocol revised to v2 (scope A: imaging-anchored primary studies, non-imaging evidence from syntheses) | by: michele
2026-10-27 | SCREEN-REBASELINE | — | screening register | 152 legacy decisions moved to `legacy` | benchmark 151 | protocol 8d8dc2e70d35
2026-10-27 | SEARCHED | — | S001 pubmed | 4465 records | 4375 new candidates (register 164→4539) | strategy q1_lesion_impairment v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S002 pubmed | 2145 records | 1380 new candidates (register 4539→5919) | strategy q1b_language_lesion_mapping v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S003 pubmed | 1041 records | 680 new candidates (register 5919→6599) | strategy q1c_cognition_prosody_lesion v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S004 pubmed | 1387 records | 132 new candidates (register 6599→6731) | strategy q2b_therapy_response_neural v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S005 pubmed | 2041 records | 0 new candidates (register 6731→6731) | strategy q3_predictor_outcome v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S006 pubmed | 1704 records | 1166 new candidates (register 6731→7897) | strategy q4_synthesis v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S007 pubmed | 908 records | 829 new candidates (register 7897→8726) | strategy q5_recruitment_meta v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S008 scopus | 8005 records | 4500 new candidates (register 8726→13226) | strategy q1_lesion_impairment v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S009 scopus | 4568 records | 1926 new candidates (register 13226→15152) | strategy q1b_language_lesion_mapping v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S010 scopus | 1563 records | 427 new candidates (register 15152→15579) | strategy q1c_cognition_prosody_lesion v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S011 scopus | 3632 records | 986 new candidates (register 15579→16565) | strategy q2b_therapy_response_neural v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S012 scopus | 3432 records | 2 new candidates (register 16565→16567) | strategy q3_predictor_outcome v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S013 scopus | 3503 records | 1510 new candidates (register 16567→18077) | strategy q4_synthesis v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S014 scopus | 1201 records | 491 new candidates (register 18077→18568) | strategy q5_recruitment_meta v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S015 psycinfo | 2319 records | 986 new candidates (register 18568→19554) | strategy q1_lesion_impairment v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S016 psycinfo | 2389 records | 979 new candidates (register 19554→20533) | strategy q1b_language_lesion_mapping v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S017 psycinfo | 625 records | 79 new candidates (register 20533→20612) | strategy q1c_cognition_prosody_lesion v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S018 psycinfo | 533 records | 28 new candidates (register 20612→20640) | strategy q2b_therapy_response_neural v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S019 psycinfo | 841 records | 1 new candidates (register 20640→20641) | strategy q3_predictor_outcome v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S020 psycinfo | 918 records | 120 new candidates (register 20641→20761) | strategy q4_synthesis v2 8d8dc2e70d35 | by: michele
2026-10-27 | SEARCHED | — | S021 psycinfo | 363 records | 51 new candidates (register 20761→20812) | strategy q5_recruitment_meta v2 8d8dc2e70d35 | by: michele
2026-10-27 | DEDUPED | — | screening register | 18 near-duplicates merged | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 1 decisions/undos | by: michele
2026-10-27 | SCREENED | — | title_abstract (screen_app) | 3 decisions/undos | by: michele
2026-10-28 | SCREENED | — | title_abstract (screen_app) | 38 decisions: exclude 1, include 37 | by: michele
2026-10-29 | GREY-EXCLUDED | — | title_abstract | 1342 records by rule (conference 263, book 857, thesis 222) | types learned 19170 | by: michele
2026-10-30 | SCREENED | — | full_text (screen_app) | 67 decisions: exclude 8, include 59 | by: michele
2026-10-30 | SEARCHED | — | S022 pubmed | 1136 records | 676 new candidates (register 20812→21488) | strategy q2c_therapy_response_patient_factors v5 4b2d56278386 | by: michele
2026-10-30 | GREY-EXCLUDED | — | title_abstract | 3 records by rule (book 3, thesis 0, conference 0) | types learned 0 | by: michele
2026-10-30 | SEARCHED | — | S023 scopus | 1695 records | 640 new candidates (register 21488→22128) | strategy q2c_therapy_response_patient_factors v5 4b2d56278386 | by: michele
2026-10-30 | SEARCHED | — | S024 psycinfo | 479 records | 91 new candidates (register 22128→22219) | strategy q2c_therapy_response_patient_factors v5 4b2d56278386 | by: michele
2026-10-30 | DEDUPED | — | screening register | 2 near-duplicates merged | by: michele
2026-10-30 | GREY-EXCLUDED | — | title_abstract | 52 records by rule (conference 16, book 11, thesis 25) | types learned 0 | by: michele
2026-10-30 | SCREENED | — | full_text:exclude 1 | 1 decisions | by: michele
2026-10-29 | SCREENED | — | full_text:exclude 1 | 1 decisions | by: michele
2026-10-30 | SCREENED | — | title_abstract (screen_app) | 56 decisions: exclude 1, include 55 | by: michele
2026-10-30 | PDFS-LINKED | — | screening register | 20 PDFs linked to their records
2026-10-30 | PDFS-LINKED | — | screening register | 7 PDFs linked to their records
2026-10-30 | PDFS-LINKED | — | screening register | 2 PDFs linked to their records
2026-10-30 | PDFS-LINKED | — | screening register | 3 PDFs linked to their records
2026-10-30 | SCREENED | — | full_text (screen_app) | 68 decisions: exclude 5, include 63 | by: michele
2026-10-30 | REGISTERED | — | screening → citations.md | 26 entries appended, 0 linked to existing keys
2026-10-30 | BACKFILLED | @SkipperKallal2017 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Stahl2013 | cohort, phase | 3 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Stefaniak2022 | cohort, phase | 5 value(s) written, 3 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Stockert2020 | cohort | 2 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Teghipco2024 | cohort, phase | 4 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @vanderMeulen2014 | cohort | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Wallentin2018 | cohort | 3 value(s) written, 0 not (no quote found) across 3 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Wilson2023 | cohort, lesion_mapping | 3 value(s) written, 0 not (no quote found) across 2 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Xing2016 | cohort | 4 value(s) written, 0 not (no quote found) across 4 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Yourganov2015Predicting | cohort, lesion_mapping, phase | 120 value(s) written, 0 not (no quote found) across 40 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | BACKFILLED | @Yourganov2016 | cohort, lesion_mapping | 11 value(s) written, 0 not (no quote found) across 6 finding(s) | model: gemma4:31b-it-q8_0
2026-10-30 | RE-EXTRACTED | @Catani2008 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Dick2012 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Durfee2021 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Fritsch2022 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Glascher2012 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Hickok2007 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Karnath2018 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Mohr2017 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Plowman2012 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Simic2019 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @Wilson2019 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @WilsonHula2019 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | RE-EXTRACTED | @vanderMeulen2014 | previous drafts moved to _compare/superseded/2026-10-30/ | current extractor (thinking off)
2026-10-30 | EXTRACTED | @Catani2008 | arcuate_fasciculus_disconnection | narrative review of AF anatomy and disconnection paradigm
2026-10-30 | EXTRACTED | @Dick2012 | connectional_anatomy_of_language, left_middle_longitudinal_fasciculus | Review of white matter pathways for language
2026-10-30 | EXTRACTED | @Durfee2021 | affective_prosody_localization | systematic review of RH prosody localization
2026-10-30 | EXTRACTED | @Fritsch2022 | thalamic_aphasia | narrative review of thalamic aphasia phenotypes and anatomy
2026-10-30 | EXTRACTED | @Glascher2012 | left_rostral_anterior_cingulate_cortex, left_middle_frontal_gyrus, left_ventromedial_prefrontal_cortex | VLSM analysis of 344 patients on cognitive control and decision-making tasks.
2026-10-30 | EXTRACTED | @Hickok2007 | dual_stream_speech_processing | narrative review of dual-stream model
2026-10-30 | EXTRACTED | @Karnath2018 | lesion_mapping_methods | narrative review of VLBM and MLBM methods
2026-10-30 | EXTRACTED | @Mohr2017 | neuroplasticity_poststroke_aphasia_mohr2017 | narrative review of therapy-induced plasticity
2026-10-30 | EXTRACTED | @Plowman2012 | aphasia_prognosis_predictors__Plowman2012 | narrative review of prognostic factors
2026-10-30 | SCREENED | — | title_abstract (screen_app) | 1 decisions: include 1 | by: michele
2026-10-30 | REVIEW-EDITED | @Fridriksson2010Anomia | bilateral_middle_frontal_gyrus_recovery | f1:source_passages | 0 reviewer mark(s) pending | reviewer: human:michele
2026-10-30 | EXTRACTED | @Mohr2017 | neuroplasticity_poststroke_aphasia_mohr2017 | narrative review of therapy-induced plasticity
2026-10-30 | EXTRACTED | @Wilson2019 | language_mapping_methods | Review of adaptive fMRI paradigms for language mapping
2026-10-30 | EXTRACTED | @WilsonHula2019 | multivariate_aphasia_approaches | narrative review of multivariate methods
2026-10-30 | EXTRACTED | @vanderMeulen2014 | melodic_intonation_therapy, time_post_onset | RCT on subacute severe nonfluent aphasia; MIT effective for repetition and communication; earlier start predicts better outcome.
2026-10-30 | EXTRACTED | @Mohr2017 | neuroplasticity_poststroke_aphasia_mohr2017 | narrative review of therapy-induced plasticity
2026-10-30 | EXTRACTED | @Simic2019 | executive_functions | Systematic review of EC as a predictor of therapy success
2026-10-30 | EXTRACTED | @Marien2004 | crossed_aphasia_dextrals | Review of 152 cases, 49 reliable CAD; findings on aphasia types, written language severity, and acalculia.
2026-10-30 | EXTRACTED | @Coppens2002 | crossed_aphasia | systematic review of 167 cases
2026-10-30 | EXTRACTED | @Lo2019 | severity_metric | Risk factors for PSCI extracted from STROKOG consortium data.
2026-10-30 | EXTRACTED | @Jiang2025 | right_dorsolateral_prefrontal_cortex, right_inferior_frontal_gyrus, left_inferior_frontal_gyrus | longitudinal fMRI DCM study on acute/subacute/chronic aphasia
2026-10-30 | EXTRACTED | @Casilio2025 | left_superior_temporal_gyrus, left_supramarginal_gyrus, left_precentral_gyrus, left_basal_ganglia | 4 findings from acute cohort (n=118) using VLSM
2026-10-30 | EXTRACTED | @Ding2023 | left_arcuate_fasciculus, left_frontal_aslant_tract, left_superior_longitudinal_fasciculus, lesion_volume | identified dorsal white matter tracts as key correlates of discourse informativeness
2026-10-30 | EXTRACTED | @Akkad2023 | left_ifg_pars_triangularis, left_posterior_stg, left_middle_temporal_gyrus | VBCM analysis of PCA factors in n=36 chronic aphasia patients
2026-10-30 | EXTRACTED | @Adezati2022 | left_posterior_stg, left_ifg_pars_triangularis | VLSM/MLPA on n=50 chronic aphasia patients
2026-10-30 | EXTRACTED | @MartinezMolina2022 | left_superior_temporal_gyrus, left_middle_temporal_gyrus, left_middle_frontal_gyrus | SVR-LSM and VBM analysis of speech vs singing production
2026-10-30 | EXTRACTED | @Ivanova2021 | left_arcuate_fasciculus | 3 findings on tract segment contributions to language
2026-10-30 | EXTRACTED | @Wilmskoetter2021 | left_ifg_pars_opercularis, left_angular_gyrus, left_middle_temporal_gyrus | 3 drafts, confidence: high
2026-10-30 | EXTRACTED | @Lukic2021 | left_superior_temporal_gyrus, left_anterior_temporal_lobe, left_angular_gyrus | VLSM analysis of sentence processing in 76 chronic aphasia patients.
2026-10-30 | EXTRACTED | @OsaGarcia2020 | initial_aphasia_severity, right_arcuate_fasciculus | Predictors of early subacute aphasia outcome
2026-10-30 | EXTRACTED | @Kristinsson2020 | left_posterior_middle_temporal_gyrus, left_angular_gyrus, left_posterior_stg, left_ifg_pars_opercularis | ROI-based regression on acute aphasia sample (n=104)
2026-10-30 | EXTRACTED | @Woollams2018 | left_anterior_temporal_lobe, left_ifg_pars_opercularis | VBCM analysis of phonology/semantics factors
2026-10-30 | EXTRACTED | @Wright2018 | imaging_metric | RH leukoaraiosis predicts naming and fluency
2026-10-30 | EXTRACTED | @Halai2018 | left_anterior_temporal_lobe, left_precentral_gyrus, left_superior_temporal_gyrus | VBCM analysis of fused impairment-paraphasia factors
2026-10-30 | EXTRACTED | @Lee2018 | left_ifg_pars_opercularis, right_ifg_pars_opercularis, left_arcuate_fasciculus_slf | DTI/VBM correlates of aphasia severity
2026-10-30 | EXTRACTED | @Xing2017 | left_uncinate_fasciculus, left_inferior_longitudinal_fasciculus, left_inferior_fronto_occipital_fasciculus, left_arcuate_fasciculus | DTI correlations of tract integrity and lesion load with WLC and SLC.
2026-10-30 | EXTRACTED | @Pillay2017 | left_middle_temporal_gyrus | VLSM study on 51 chronic LH stroke patients; MTG identified as specific substrate for multiword integration.
2026-10-30 | EXTRACTED | @Basilakos2014 | left_anterior_arcuate_fasciculus, left_frontal_aslant_tract, left_uncinate_fasciculus | VBCM analysis of 76 chronic stroke patients
2026-10-30 | EXTRACTED | @Han2016 | left_arcuate_fasciculus_slf | Causal link between left SLF integrity and phonological production deficits.
2026-10-30 | EXTRACTED | @Rosso2015 | left_temporoparietal_white_matter_crossroad, lesion_volume | DTI regression and correlation analysis of global aphasia severity
2026-10-30 | EXTRACTED | @Fridriksson2015 | left_ifg_pars_opercularis, left_superior_temporal_gyrus | VLSM study (n=70) showing Broca's aphasia requires damage to both Broca's and Wernicke's areas.
2026-10-30 | EXTRACTED | @Stahl2011 | left_basal_ganglia, melodic_intonation_therapy | Basal ganglia lesions predict rhythm benefit; singing showed no effect over rhythmic speech.
2026-10-30 | EXTRACTED | @Schlaug2010 | melodic_intonation_therapy, right_arcuate_fasciculus | 3 findings extracted from a special report including case-series data.
2026-10-30 | EXTRACTED | @Sheppard2022 | left_supramarginal_gyrus, left_arcuate_fasciculus_slf, left_ifg_pars_opercularis, left_posterior_stg | longitudinal LASSO regression on acute vs chronic sentence comprehension
2026-10-30 | EXTRACTED | @Bi2015 | left_arcuate_fasciculus_slf, left_inferior_frontooccipital_fasciculus, left_uncinate_fasciculus, left_anterior_thalamic_radiation | Causal role of WM tracts in tool processing using tractography and VLSM/VFSM.
2026-10-30 | EXTRACTED | @Ali2021 | age, time_post_onset | IPD meta-analysis of 174 studies; age <55 and enrollment <1 month predict greatest recovery.
2026-10-30 | MODEL-APPROVED | @OsaGarcia2020 | initial_aphasia_severity | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-30 | MODEL-APPROVED | @Rosso2015 | lesion_volume | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-30 | MODEL-APPROVED | @Kristinsson2020 | left_angular_gyrus | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-30 | MODEL-APPROVED | @Xing2017 | left_arcuate_fasciculus | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-30 | MODEL-APPROVED | @Lee2018 | left_arcuate_fasciculus_slf | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-31 | MODEL-APPROVED | @Kristinsson2020 | left_ifg_pars_opercularis | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
2026-10-31 | MODEL-APPROVED | @Lee2018 | left_ifg_pars_opercularis | reviewer: model:gemma4:26b | extractor: agent:ollama-extract-cli/gemma4:31b-it-q8_0 | tier: A
