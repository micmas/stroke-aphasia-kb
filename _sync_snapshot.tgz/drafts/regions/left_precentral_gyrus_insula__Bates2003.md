---
schema_version: 2.7
id: left_precentral_gyrus_insula
name: Left precentral gyrus of the insula
kind: classical
status: draft
created_by: agent:ollama-extract-cli/gemma4:31b-it-q8_0
created_on: 2026-10-20
hemisphere: left
findings:
- id: f1
  target: fluency
  target_kind: impairment
  claim: Damage to the left anterior insula is strongly associated with reduced speech fluency.
  direction: likely
  relationship: causal
  citation: '@Bates2003'
  method: VLSM
  design: cross-sectional
  strength: strong
  evidence_quality: cohort
  sample:
    n: 101
    population: left-hemisphere-damaged aphasic patients
    time_post_onset: at least one year after stroke
    age_range: not_reported
    handedness: not_reported
    language: native English speakers
    phase: not_reported
    cohort: not_reported
  statistics:
    threshold: P = 0.05 (controlling the expected proportion of false positives)
    effect_size: not_reported
  confounders_controlled: []
  confounders_not_controlled:
  - lesion volume
  region_definition:
    kind: data_driven_cluster
    description: Voxel-based lesion-symptom mapping peak for fluency.
  imaging_details:
    reference_space: other
    atlases_used: []
    preprocessing_pipeline: Lesions reconstructed onto templates by a board-certified neurologist.
  author_limitations:
  - An area may emerge as relevant either because it has a direct causal role or because of a diaschitic
    effect.
  provenance:
    extracted_by: agent
    extracted_on: 2026-01-01
    paper_section: Results, page 449
    confidence: high
    flags:
    - reference_space is described as stereotactic templates but specific atlas not named
  source_passages:
  - section: Results
    page: 2
    quote: Fluency was most affected by lesions in the insula
    supports: claim
  - section: Methods
    page: 2
    quote: We analyzed data on speech fluency and language comprehension for 101 left-hemisphere-injured
      stroke patients
    supports: sample
  - section: Figure 1 caption
    page: 2
    quote: Only voxels that were significant at P = 0.05 (controlling the expected proportion of false
      positives) are shown.
    supports: statistics
  - section: Discussion
    page: 3
    quote: an area may emerge as relevant either because it has a direct causal role or because of a diaschitic
      effect
    supports: limitation
  - section: added by backfill
    page: 1
    quote: We applied VLSM to measures of speech fluency and language comprehension in 101 left-hemisphere-damaged
      aphasic patients
    supports: method
  lesion_mapping:
    analysis: univariate
    n_analysed: 101
    min_lesion_overlap: not_reported
    lesion_volume_correction: not_reported
    multiple_comparisons: fdr
  filled:
    by: model:gemma4:31b-it-q8_0
    date: '2026-10-26'
    tool: backfill.py
    fields:
    - cohort
    - lesion_mapping
- id: f2
  target: fluency
  target_kind: impairment
  claim: The anterior insula is critical for speech fluency independently of damage to Broca's area.
  direction: likely
  relationship: causal
  citation: '@Bates2003'
  method: VLSM
  design: cross-sectional
  strength: strong
  evidence_quality: cohort
  sample:
    n: 101
    population: left-hemisphere-damaged aphasic patients
    time_post_onset: at least one year after stroke
    age_range: not_reported
    handedness: not_reported
    language: native English speakers
    phase: not_reported
    cohort: not_reported
  statistics:
    threshold: not_reported
    effect_size: not_reported
  confounders_controlled:
  - Broca's area lesion state
  confounders_not_controlled:
  - lesion volume
  region_definition:
    kind: manual_ROI
    description: Central voxel in the anterior insula used as covariate in ANCOVA.
  imaging_details:
    reference_space: other
    atlases_used: []
  author_limitations:
  - An area may emerge as relevant either because it has a direct causal role or because of a diaschitic
    effect.
  provenance:
    extracted_by: agent
    extracted_on: 2026-01-01
    paper_section: Results, page 450
    confidence: high
    flags: []
  source_passages:
  - section: Results
    page: 3
    quote: These maps showed that the anterior insula is critical for fluency, independent of Broca's
      area
    supports: claim
  - section: Results
    page: 3
    quote: We constructed four maps factoring out the effects of these voxels by carrying out analyses
      of covariance (ANCOVAs)
    supports: method
  - section: added by backfill
    page: 3
    quote: We constructed four maps factoring out the effects of these voxels by carrying out analyses
      of covariance (ANCOVAs) at all other voxels using the state (intact or lesioned) of each voxel of
      interest as the covariates
    supports: method
  - section: added by backfill
    page: 2
    quote: We analyzed data on speech fluency and language comprehension for 101 left-hemisphere-injured
      stroke patients
    supports: method
  lesion_mapping:
    analysis: multivariate
    n_analysed: 101
    min_lesion_overlap: not_reported
    lesion_volume_correction: not_reported
    multiple_comparisons: not_reported
  filled:
    by: model:gemma4:31b-it-q8_0
    date: '2026-10-26'
    tool: backfill.py
    fields:
    - cohort
    - lesion_mapping
---
