---
schema_version: 2.8
id: left_hippocampus
name: Left Hippocampus
kind: classical
status: draft
created_by: agent:ollama-extract-cli/gemma4:31b-it-q8_0
created_on: 2026-10-21
hemisphere: left
findings:
- id: f1
  target: severity_metric
  target_kind: predictor
  claim: Reduced volume of the left hippocampus is associated with smaller improvements in naming after
    intensive language therapy in chronic aphasia.
  direction: likely
  relationship: responder
  citation: '@Meinzer2010'
  method:
  - DTI
  - RLSM
  design: longitudinal
  strength: moderate
  evidence_quality: cohort
  sample:
    n: 10
    population: chronic post-stroke aphasia
    time_post_onset: mean 5.42 years (range 1.8-9.4)
    age_range: mean 50.6 (SD 9.2), range 34-67
    handedness: all right-handed
    language: German
    phase: chronic
    cohort: not_reported
  statistics:
    threshold: p < 0.05
    effect_size: r = 0.65
    p_value: 0.04
  confounders_controlled: []
  confounders_not_controlled:
  - lesion volume
  - duration of aphasia
  - education
  - apraxia of speech
  - motivation
  region_definition:
    kind: manual_ROI
    description: Manually defined ROI including hippocampal body, dentate gyrus, uncus, fimbria, alveus,
      and subiculum.
  imaging_details:
    field_strength: 3T
    modalities:
    - modality: T1
      sequence: 3D Fast gradient echo (TFE)
      voxel_size_mm:
      - 0.5
      - 0.5
      - 0.5
      TR_ms: 7.4
      TE_ms: 3.4
    preprocessing_pipeline: SPM2 + in-house C++/Matlab routines; registered to MNI space
    reference_space: MNI152
    atlases_used: []
  author_limitations:
  - Small sample size (n=10).
  - Results may not generalize to patients with severe apraxia of speech.
  - Causality between structure and function not established; requires longitudinal design.
  provenance:
    extracted_by: agent
    extracted_on: 2026-01-01
    paper_section: Results, page 5
    confidence: high
    flags: []
  source_passages:
  - section: Results
    page: 5
    quote: 'Both measures were highly and inversely correlated with improved performance on the TrO immediately
      after the training (LIs volume reduction: r=0.65, p=.04; FA-reduction: r=0.85, p=0.001) and with
      the retention of treatment gains 8 months after the training (volume reduction: r=0.80, p=0.005;
      FA-reduction: r=0.83, p=0.002; Fig. 3).'
    supports: claim
  - section: Materials and methods
    page: 2
    quote: Ten consecutively recruited patients (3 women, 7 men; all right-handed, mean age 50.6±9.2 years,
      range 34–67; time since stroke 5.42±1.9 years, range 1.8–9.4; years of education 12.7±4.6, range
      8–20; Table 1) with chronic post-stroke aphasia due to a single first-time infarct and moderate
      to severe word-retrieval difficulties (anomia) were studied.
    supports: sample
  - section: Volumetric analysis of the hippocampus
    page: 4
    quote: Two regions of interest (left and right hippocampus; ROIHC), based on the high resolution T1-weighted
      structural images of each patient, were manually defined.
    supports: region_definition
  - section: Magnetic resonance imaging
    page: 3
    quote: Data were acquired prior to the intensive language training using a 3-Tesla whole body MR system
      (Philips Gyroscan Intera).
    supports: imaging_details
  - section: Discussion
    page: 7
    quote: Our results should be treated as preliminary... our results cannot be generalized to patients
      with severe apraxia of speech.
    supports: limitation
  - section: added by backfill
    page: 5
    quote: these measures were correlated with naming performance for TrO and UnTrO
    supports: method
  - section: added by backfill
    page: 5
    quote: 'Training success for TrO was neither correlated with duration of aphasia (post-pre: r=−0.07,
      p=0.84) nor with lesion size (post-pre: r=−0.10, p=0.78; follow-up-pre: r=-−0.20, p=0.56).'
    supports: method
  - section: added by backfill
    page: 2
    quote: Ten consecutively recruited patients
    supports: method
  - section: added by backfill
    page: 2
    quote: In short, patients received 3 h daily of computer-assisted naming treatment over a period of
      2 weeks.
    supports: method
  lesion_mapping:
    analysis: univariate
    n_analysed: 10
    min_lesion_overlap: not_reported
    lesion_volume_correction: none
    multiple_comparisons: uncorrected
  filled:
    by: model:gemma4:31b-it-q8_0
    date: '2026-10-27'
    tool: backfill.py
    fields:
    - cohort
    - lesion_mapping
    - therapy
  therapy:
    id: intensive_naming_treatment
    name: intensive naming treatment
    dose: 3 h daily of computer-assisted naming treatment over a period of 2 weeks
- id: f2
  target: severity_metric
  target_kind: predictor
  claim: Reduced microstructural integrity (FA) of the white matter surrounding the left hippocampus is
    associated with smaller improvements in naming after intensive language therapy.
  direction: likely
  relationship: responder
  citation: '@Meinzer2010'
  method: DTI
  design: longitudinal
  strength: moderate
  evidence_quality: cohort
  sample:
    n: 10
    population: chronic post-stroke aphasia
    time_post_onset: mean 5.42 years (range 1.8-9.4)
    age_range: mean 50.6 (SD 9.2), range 34-67
    handedness: all right-handed
    language: German
    phase: chronic
    cohort: not_reported
  statistics:
    threshold: p < 0.05
    effect_size: r = 0.85
    p_value: 0.001
  confounders_controlled: []
  confounders_not_controlled:
  - lesion volume
  - duration of aphasia
  - education
  - apraxia of speech
  - motivation
  region_definition:
    kind: manual_ROI
    description: FA-ROI generated by symmetrically expanding the hippocampal ROI with Gaussian kernels
      (4, 8, 12 mm) and subtracting the original ROI.
  imaging_details:
    field_strength: 3T
    modalities:
    - modality: DTI
      sequence: Spin-Echo single shot Echo Planar Imaging (SE-EPI)
      voxel_size_mm:
      - 0.9375
      - 0.9375
      - 3.6
      TR_ms: 9473
      TE_ms: 95
      n_directions: 20
      b_values:
      - 0
      - 1000
    preprocessing_pipeline: SPM2 + in-house C++/Matlab; registered to MNI space; motion and eddy-current
      correction
    reference_space: MNI152
    atlases_used: []
  author_limitations:
  - Small sample size (n=10).
  - Results may not generalize to patients with severe apraxia of speech.
  - Causality between structure and function not established; requires longitudinal design.
  provenance:
    extracted_by: agent
    extracted_on: 2026-01-01
    paper_section: Results, page 5
    confidence: high
    flags: []
  source_passages:
  - section: Results
    page: 5
    quote: 'Both measures were highly and inversely correlated with improved performance on the TrO immediately
      after the training (LIs volume reduction: r=0.65, p=.04; FA-reduction: r=0.85, p=0.001) and with
      the retention of treatment gains 8 months after the training (volume reduction: r=0.80, p=0.005;
      FA-reduction: r=0.83, p=0.002; Fig. 3).'
    supports: claim
  - section: FA-ROI analysis of fiber integrity
    page: 4
    quote: 'To assess FA-values as an indicator of white matter fiber integrity in areas surrounding the
      right and left hippocampi... two FA-ROIs were generated based on the individual patient''s ROIHC:
      The ROIHC was first symmetrically expanded by a Gaussian smoothing kernel (ROIexp).'
    supports: region_definition
  - section: Diffusion tensor imaging (DTI)
    page: 3
    quote: DTI data were acquired with a multi slice Spin-Echo single shot Echo Planar Imaging sequence
      (SE-EPI) for spin-echo diffusion weighting, TR=9473 ms, TE=95 ms... each slice was acquired 20 times
      with diffusion weighting gradients (b factor 1000 s/mm2) in 20 isotropic directions and 3 times
      without diffusion weighting (b=0 s/mm2).
    supports: imaging_details
  - section: Discussion
    page: 7
    quote: Our results should be treated as preliminary... our results cannot be generalized to patients
      with severe apraxia of speech.
    supports: limitation
  - section: added by backfill
    page: 2
    quote: In short, patients received 3 h daily of computer-assisted naming treatment over a period of
      2 weeks.
    supports: method
  filled:
    by: model:gemma4:31b-it-q8_0
    date: '2026-10-27'
    tool: backfill.py
    fields:
    - cohort
    - therapy
  therapy:
    id: intensive_naming_treatment
    name: intensive naming treatment
    dose: 3 h daily of computer-assisted naming treatment over a period of 2 weeks
---
Findings from Meinzer et al. (2010) indicate that both the volume and the surrounding white matter integrity of the left hippocampus are critical predictors of success in intensive naming therapy for chronic aphasia.
