---
schema_version: 2.8
id: left_supramarginal_gyrus_premotor
name: Left Supramarginal Gyrus and Premotor Cortex (supra-Sylvian)
kind: classical
status: draft
created_by: agent:ollama-extract-cli/gemma4:31b-it-q8_0
created_on: 2026-10-20
hemisphere: left
findings:
- id: f1
  target: anomia
  target_kind: impairment
  claim: Increased activation in the left inferior parietal lobule following treatment is associated with
    improved naming performance.
  direction: likely
  relationship: treatment_response
  citation: '@Fridriksson2010Anomia'
  method: fMRI_activation
  design: longitudinal
  strength: moderate
  evidence_quality: cohort
  sample:
    n: 19
    population: chronic stroke and concomitant aphasia
    time_post_onset: '>= 8 months'
    age_range: mean 59.7 (SD 12.3)
    handedness: not_reported
    language: not_reported
    phase: chronic
    cohort: not_reported
  statistics:
    threshold: Z = 2.3, p < 0.05 (corrected)
    effect_size: Z = 3.01
    p_value: not_reported
  confounders_controlled: []
  confounders_not_controlled: []
  region_definition:
    kind: data_driven_cluster
    description: Part of the posterior cluster associated with naming improvement, specifically the inferior
      parietal lobule.
  imaging_details:
    field_strength: 3T
    modalities:
    - modality: fMRI
      sequence: T2*-MRI echoplanar imaging
      voxel_size_mm:
      - 3.25
      - 3.25
      - 3.25
      TR_ms: 10000
      TE_ms: 30
      volumes: 120
    task:
      name: Picture naming
      description: Overt naming of 80 pictures randomly selected from treatment sets, contrasted with
        40 abstract pictures.
      contrasts:
      - correctly named pictures versus viewed abstract pictures
      baseline: abstract pictures
    preprocessing_pipeline: 'FSL 4.1: motion correction, non-brain removal, 8mm Gaussian smoothing, grand-mean
      intensity normalization, high-pass temporal filtering (80s)'
    reference_space: MNI152
    atlases_used:
    - Talairach Daemon
    - Brodmann's area map
    coordinates_reported:
    - region: Inferior parietal lobule
      mni:
      - 48
      - -40
      - 48
  author_limitations:
  - the current fMRI analysis did not deduce which of these areas is more important than others or the
    dynamics of change needed to support recovery.
  provenance:
    extracted_by: agent
    extracted_on: 2026-01-01
    paper_section: 'Results - Primary outcome: fMRI results'
    confidence: high
    flags:
    - cohort overlaps with @Fridriksson2010 (as stated in paper)
    - retargeted anomic_aphasia → anomia (symptom, v2.8) on 2026-10-26
  source_passages:
  - section: Results
    page: 4
    quote: A positive relationship was revealed between treatment-assisted increase in correct naming
      and modulation of cortical areas in the left posterior and anterior hemisphere
    supports: claim
  - section: Materials and Methods
    page: 2
    quote: Twenty-six patients (14 women) with chronic stroke and concomitant aphasia were included.
    supports: sample
  - section: Materials and Methods
    page: 3
    quote: The third and final level included a regression analysis in which data from all participants
      were combined to predict treatment outcome (i.e., change in correct naming).
    supports: method
  - section: Materials and Methods
    page: 3
    quote: Z (Gaussianised T/F) statistic images were thresholded using clusters determined by Z = 2.3
      and a (corrected) cluster significance threshold of p = 0.05
    supports: statistics
  - section: Discussion
    page: 5
    quote: the current fMRI analysis did not deduce which of these areas is more important than others
      or the dynamics of change needed to support recovery.
    supports: limitation
  - section: added by backfill
    page: 2
    quote: the treatment, usually referred to as a "cueing hierarchy," is based on using verbal cues of
      increasing cueing strength to elicit correct naming of colored pictures shown on a computer screen.
    supports: method
  filled:
    by: model:gemma4:31b-it-q8_0
    date: '2026-10-27'
    tool: backfill.py
    fields:
    - cohort
    - therapy
  edits:
  - by: tool:retarget_symptoms.py
    date: '2026-10-26'
    fields:
    - target
  therapy:
    id: cueing_hierarchy
    name: cueing hierarchy
    dose: 30 h
---
Finding f1 links increased activation in the left inferior parietal lobule to improved naming outcomes following intensive treatment.
