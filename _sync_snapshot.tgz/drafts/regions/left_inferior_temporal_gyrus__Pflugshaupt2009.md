---
schema_version: 2.7
id: left_inferior_temporal_gyrus
name: Left Inferior Temporal Gyrus
kind: classical
status: draft
created_by: agent:ollama-extract-cli/gemma4:31b-it-q8_0
created_on: 2026-10-20
hemisphere: left
findings:
- id: f1
  target: pure_alexia
  target_kind: impairment
  claim: Damage to the left inferior temporal gyrus is associated with pure alexia.
  direction: likely
  relationship: causal
  citation: '@Pflugshaupt2009'
  method: LSM
  design: cross-sectional
  strength: moderate
  evidence_quality: cohort
  sample:
    n: 12
    population: patients with pure alexia and hemianopic dyslexia
    time_post_onset: not_reported
    age_range: not_reported
    handedness: all right-handed
    language: German
    phase: not_reported
    cohort: not_reported
  statistics:
    threshold: not_reported
    cluster_extent: not_reported
    effect_size: identified as one of the largest group differences in subtraction analysis
    p_value: not_reported
  confounders_controlled:
  - ' visual field defect side'
  - degree of macular sparing
  confounders_not_controlled: []
  region_definition:
    kind: data_driven_cluster
    description: Left inferior temporal gyrus identified via lesion subtraction analysis (pure alexia
      minus hemianopic dyslexia).
  imaging_details:
    field_strength: not_reported
    acquisition:
      voxel_size_mm: not_reported
      TR_ms: not_reported
      TE_ms: not_reported
      sequence: not_reported
    preprocessing_pipeline: Manual tracing onto CH2 template brain using MRIcro software
    reference_space: MNI152
    atlases_used:
    - AAL
    coordinates_reported: []
  author_limitations:
  - Small sample size may lead to underestimation of visuo-motor deficits.
  provenance:
    extracted_by: agent
    extracted_on: 2026-01-01
    paper_section: Results - Lesion analysis, page 6
    confidence: high
    flags:
    - target_id pure_alexia is forward-looking
  source_passages:
  - section: Abstract
    page: 1
    quote: subtracting the lesions of the hemianopic dyslexics from those found in pure alexics revealed
      the largest group differences in posterior parts of the left fusiform gyrus, occipito-temporal sulcus
      and inferior temporal gyrus.
    supports: claim
  - section: Methods - Lesion analysis
    page: 5
    quote: brain lesions were manually drawn from clinical MR or CT scans onto axial slices of the CH2
      template brain.
    supports: method
  - section: Discussion
    page: 9
    quote: due to relatively small sample sizes and thus limited statistical power, these comparisons
      are likely to underestimate visuo-motor deficits in patients
    supports: limitation
  - section: added by backfill
    page: 1
    quote: six patients with pure alexia were identiﬁed from the population of in-patients at our unit
      of cognitive and restorative neurology.
    supports: method
  - section: added by backfill
    page: 1
    quote: six patients with hemianopic dyslexia due to right-sided visual ﬁeld loss participated as a
      clinical control group.
    supports: method
  - section: added by backfill
    page: 6
    quote: the lesions of hemianopic dyslexia patients were subtracted from those of pure alexia patients.
    supports: method
  lesion_mapping:
    analysis: region_based
    n_analysed: 12
    min_lesion_overlap: not_reported
    lesion_volume_correction: not_reported
    multiple_comparisons: not_reported
  filled:
    by: model:gemma4:31b-it-q8_0
    date: '2026-10-26'
    tool: backfill.py
    fields:
    - cohort
    - lesion_mapping
---
# Left Inferior Temporal Gyrus

Findings from Pflugshaupt et al. (2009) indicate that the left inferior temporal gyrus is a key region whose damage is associated with pure alexia, as revealed by lesion subtraction against hemianopic dyslexia.
